<?php
session_start();
require_once 'db_connect.php';

if (isset($_GET['token'])) {
    $token = $_GET['token'];
    $now = date('Y-m-d H:i:s');
    
    try {
        $conn->begin_transaction();
        
        // Check if token is valid and not expired
        $stmt = $conn->prepare("SELECT user_id FROM email_verifications WHERE token = ? AND expires_at > ?");
        $stmt->bind_param("ss", $token, $now);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $verification = $result->fetch_assoc();
            $user_id = $verification['user_id'];
            
            // Activate user account
            $update_stmt = $conn->prepare("UPDATE users SET is_verified = 1, active_status = 1 WHERE id = ?");
            $update_stmt->bind_param("i", $user_id);
            $update_stmt->execute();
            
            // Delete verification record
            $delete_stmt = $conn->prepare("DELETE FROM email_verifications WHERE token = ?");
            $delete_stmt->bind_param("s", $token);
            $delete_stmt->execute();
            
            $conn->commit();
            
            $_SESSION['success_message'] = "Account activated successfully! You can now login.";
        } else {
            $_SESSION['error_message'] = "Invalid or expired activation link.";
        }
    } catch (Exception $e) {
        $conn->rollback();
        $_SESSION['error_message'] = "Activation failed. Please try again.";
    }
    
    header("Location: login.php");
    exit();
}