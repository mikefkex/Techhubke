<?php
session_start();
require_once 'db_connect.php';

// Check if user is pending activation
if (!isset($_SESSION['pending_activation'])) {
    header("Location: login.php");
    exit();
}

// Get user email for resend functionality
$stmt = $conn->prepare("SELECT email, activation_token FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION['pending_activation']);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$message = "";
if (isset($_POST['resend_activation'])) {
    // Generate new token and expiry
    $new_token = bin2hex(random_bytes(32));
    $new_expiry = date('Y-m-d H:i:s', strtotime('+24 hours'));
    
    $update_stmt = $conn->prepare("UPDATE users SET activation_token = ?, token_expires_at = ? WHERE id = ?");
    $update_stmt->bind_param("ssi", $new_token, $new_expiry, $_SESSION['pending_activation']);
    $update_stmt->execute();
    
    // Send new activation email
    $activation_link = "https://mpesapay.techhubke.site/activate.php?token=$new_token";
    $subject = "Activate Your Outlier Account";
    $message = "
        <h2>Account Activation</h2>
        <p>Here's your new activation link:</p>
        <p><a href='$activation_link'>Activate Account</a></p>
        <p>This link will expire in 24 hours.</p>
    ";
    
    $headers = [
        'From' => 'Outlier <info@techhubke.site>',
        'Content-Type' => 'text/html; charset=UTF-8'
    ];
    
    mail($user['email'], $subject, $message, $headers);
    
    $message = "New activation link sent to your email!";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Activation Required</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        .container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 30px;
            width: 100%;
            max-width: 500px;
            text-align: center;
        }
        .success-message {
            background-color: #e8f5e9;
            color: #2e7d32;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        button {
            background-color: #4a6baf;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 15px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Account Activation Required</h2>
        <p>Please check your email (<strong><?php echo $user['email']; ?></strong>) for the activation link.</p>
        
        <?php if (!empty($message)): ?>
            <div class="success-message"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <p>Didn't receive the email?</p>
        <form method="post">
            <button type="submit" name="resend_activation">Resend Activation Email</button>
        </form>
        
        <p style="margin-top: 20px;">
            <a href="login.php">Back to Login</a>
        </p>
    </div>
</body>
</html>