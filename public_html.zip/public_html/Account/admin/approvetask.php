<?php
session_start();
// Redirect to login if not authenticated
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

include 'db_connection.php';

// Initialize variables
$error = "";
$success = "";

// Handle task approval/rejection
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $task_id = isset($_POST['task_id']) ? $_POST['task_id'] : 0;
    $status = isset($_POST['status']) ? $_POST['status'] : '';
    
    if (empty($task_id) || !in_array($status, ['approved', 'rejected'])) {
        $error = "Invalid request parameters!";
    } else {
        try {
            // Begin transaction
            $conn->begin_transaction();
            
            // Update the task status
            $stmt = $conn->prepare("UPDATE completed_tasks SET status = ? WHERE id = ?");
            $stmt->bind_param("si", $status, $task_id);
            $stmt->execute();
            
            // If approved, update user's balance
            if ($status === 'approved') {
                // Get task amount and user_id
                $query = "SELECT ct.user_id, at.amount 
                          FROM completed_tasks ct 
                          JOIN available_tasks at ON ct.task_id = at.id 
                          WHERE ct.id = ?";
                $stmt2 = $conn->prepare($query);
                $stmt2->bind_param("i", $task_id);
                $stmt2->execute();
                $result = $stmt2->get_result();
                
                if ($row = $result->fetch_assoc()) {
                    $user_id = $row['user_id'];
                    $amount = $row['amount'];
                    
                    // Update user balance
                    $update_user = $conn->prepare("UPDATE users SET amount = amount + ? WHERE id = ?");
                    $update_user->bind_param("di", $amount, $user_id);
                    $update_user->execute();
                    $update_user->close();
                }
                $stmt2->close();
            }
            
            // Commit transaction
            $conn->commit();
            $success = "Task has been " . $status . " successfully!";
            
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            $error = "Database error: " . $e->getMessage();
        }
    }
}

// Pagination setup
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Get total count for pagination
$count_query = "SELECT COUNT(*) as total FROM completed_tasks WHERE status = 'pending'";
$count_result = $conn->query($count_query);
$row = $count_result->fetch_assoc();
$total_records = $row['total'];
$total_pages = ceil($total_records / $per_page);

// Get pending tasks with user and task details
$query = "SELECT ct.id, ct.submission, ct.created_at, 
          u.username, u.full_name, 
          at.task_type, at.description, at.amount
          FROM completed_tasks ct
          JOIN users u ON ct.user_id = u.id
          JOIN available_tasks at ON ct.task_id = at.id
          WHERE ct.status = 'pending'
          ORDER BY ct.created_at ASC
          LIMIT ? OFFSET ?";

$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $per_page, $offset);
$stmt->execute();
$result = $stmt->get_result();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css" >
    <title>Approve Tasks</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
        }

        .sidebar {
            width: 250px;
            background-color: #333;
            color: #fff;
            height: 100vh;
            padding: 20px;
        }

        .sidebar h2 {
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            margin-bottom: 10px;
        }

        .sidebar ul li a {
            color: #fff;
            text-decoration: none;
            display: block;
            padding: 8px;
            border-radius: 4px;
        }

        .sidebar ul li a:hover, .sidebar ul li a.active {
            background-color: #555;
        }

        .main-content {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        .alert {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }

        .task-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
            background-color: #fff;
        }

        .task-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }

        .task-header h3 {
            margin: 0;
            color: #333;
        }

        .task-details {
            margin-bottom: 15px;
        }

        .task-details p {
            margin: 5px 0;
        }

        .task-submission {
            background-color: #f9f9f9;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }

        .task-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }

        .task-actions form {
            display: inline;
        }

        .btn {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            color: white;
        }

        .btn-approve {
            background-color: #28a745;
        }

        .btn-reject {
            background-color: #dc3545;
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .pagination a {
            color: #333;
            padding: 8px 16px;
            text-decoration: none;
            border: 1px solid #ddd;
            margin: 0 4px;
        }

        .pagination a.active {
            background-color: #007bff;
            color: white;
            border: 1px solid #007bff;
        }

        .pagination a:hover:not(.active) {
            background-color: #ddd;
        }

        .no-tasks {
            text-align: center;
            padding: 50px 0;
            color: #666;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <ul>

           <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="creattask.php">Create Task</a></li>
            <li><a href="approvetask.php">Create Task</a></li>
            <li><a href="users.php">Manage Users</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container">
            <h1>Approve Tasks</h1>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <?php if ($result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <div class="task-card">
                        <div class="task-header">
                            <h3><?php echo htmlspecialchars($row['task_type']); ?></h3>
                            <span>$<?php echo number_format($row['amount'], 2); ?></span>
                        </div>
                        
                        <div class="task-details">
                            <p><strong>User:</strong> <?php echo htmlspecialchars($row['full_name']); ?> (<?php echo htmlspecialchars($row['username']); ?>)</p>
                            <p><strong>Task Description:</strong> <?php echo htmlspecialchars($row['description']); ?></p>
                            <p><strong>Submitted:</strong> <?php echo date("F j, Y, g:i a", strtotime($row['created_at'])); ?></p>
                        </div>
                        
                        <div class="task-submission">
                            <strong>Submission:</strong>
                            <div><?php echo nl2br(htmlspecialchars($row['submission'])); ?></div>
                        </div>
                        
                        <div class="task-actions">
                            <form method="POST">
                                <input type="hidden" name="task_id" value="<?php echo $row['id']; ?>">
                                <input type="hidden" name="status" value="approved">
                                <button type="submit" class="btn btn-approve">Approve</button>
                            </form>
                            
                            <form method="POST">
                                <input type="hidden" name="task_id" value="<?php echo $row['id']; ?>">
                                <input type="hidden" name="status" value="rejected">
                                <button type="submit" class="btn btn-reject">Reject</button>
                            </form>
                        </div>
                    </div>
                <?php endwhile; ?>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?php echo ($page - 1); ?>">&laquo;</a>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <a href="?page=<?php echo $i; ?>" <?php echo ($i == $page) ? 'class="active"' : ''; ?>><?php echo $i; ?></a>
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="?page=<?php echo ($page + 1); ?>">&raquo;</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
            <?php else: ?>
                <div class="no-tasks">
                    <h3>No pending tasks to approve</h3>
                    <p>All submitted tasks have been reviewed.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>