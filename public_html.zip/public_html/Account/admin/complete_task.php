<?php
// complete_task.php
session_start();
require 'db_connection.php'; // Include your database connection file

// Redirect if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Check if task_id is provided in the URL
if (!isset($_GET['task_id'])) {
    header("Location: task.php"); // Redirect if no task ID is provided
    exit();
}

$task_id = $_GET['task_id']; // Get the task ID from the URL

// Fetch task details from available_tasks
$task_sql = "SELECT id, task_type, description, amount FROM available_tasks WHERE id = ?";
$task_stmt = $conn->prepare($task_sql);
$task_stmt->bind_param("i", $task_id);
$task_stmt->execute();
$task_result = $task_stmt->get_result();

if ($task_result->num_rows == 0) {
    echo "<p>Task not found.</p>";
    exit();
}

$task = $task_result->fetch_assoc(); // Get task details

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submission = $_POST['submission'];

    // Insert the completed task into the completed_tasks table
    $insert_sql = "INSERT INTO completed_tasks (user_id, task_id, submission, status) 
                   VALUES (?, ?, ?, 'pending')";
    $insert_stmt = $conn->prepare($insert_sql);
    $insert_stmt->bind_param("iis", $user_id, $task_id, $submission);

    if ($insert_stmt->execute()) {
        $success = "Task submitted successfully! Waiting for admin approval.";
    } else {
        $error = "Error submitting task: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete Task</title>
    <link href="css/app.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .task-details {
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .task-details p {
            margin: 5px 0;
        }
        .error {
            color: red;
            margin-bottom: 15px;
        }
        .success {
            color: green;
            margin-bottom: 15px;
        }
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar and Navbar code remains the same -->
        <!-- ... -->

        <main class="content">
            <div class="container-fluid p-0">
                <h1 class="h3 mb-3"><strong>Complete Task</strong></h1>

                <!-- Display Error or Success Messages -->
                <?php if ($error): ?>
                    <div class="error"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="success"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>

                <!-- Display Task Details -->
                <div class="task-details">
                    <h3><?php echo htmlspecialchars($task['task_type']); ?></h3>
                    <p><strong>Description:</strong> <?php echo htmlspecialchars($task['description']); ?></p>
                    <p><strong>Amount:</strong> $<?php echo number_format($task['amount'], 2); ?></p>
                </div>

                <!-- Submission Form -->
                <form method="POST" action="">
                    <label for="submission"><strong>Your Submission:</strong></label><br>
                    <textarea id="submission" name="submission" rows="10" required></textarea><br>
                    <button type="submit">Submit Task</button>
                </form>
            </div>
        </main>

        <!-- Footer code remains the same -->
        <!-- ... -->
    </div>

    <script src="js/app.js"></script>
</body>
</html>