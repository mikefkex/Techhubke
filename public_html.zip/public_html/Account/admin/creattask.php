<?php
session_start();
// Redirect to login if not authenticated
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

include 'db_connection.php';

// Initialize variables
$error = "";
$success = "";

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $task_type = trim($_POST['task_type']);
    $title = trim($_POST['title']); // Added title field
    $description = trim($_POST['description']);
    $amount = trim($_POST['amount']);
    $created_by = $_SESSION['admin_id']; // Get admin ID from session

    // Validate inputs
    if (empty($task_type) || empty($title) || empty($description) || empty($amount)) {
        $error = "All fields are required!";
    } elseif (!is_numeric($amount) || $amount <= 0) {
        $error = "Amount must be a positive number!";
    } else {
        // Insert into database
        try {
            $stmt = $conn->prepare("INSERT INTO available_tasks 
                                   (task_type, title, description, amount, created_by) 
                                   VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssdi", $task_type, $title, $description, $amount, $created_by);
            
            if ($stmt->execute()) {
                $success = "Task created successfully!";
                // Clear form on success
                $_POST = array();
            } else {
                $error = "Error: " . $stmt->error;
            }
            
            $stmt->close();
        } catch (mysqli_sql_exception $e) {
            $error = "Database error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Task</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
        }

        .sidebar {
            width: 250px;
            background-color: #2c3e50;
            color: #fff;
            height: 100vh;
            padding: 20px;
            position: fixed;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 10px;
            border-bottom: 1px solid #444;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar li {
            margin-bottom: 10px;
        }

        .sidebar a {
            color: #ecf0f1;
            text-decoration: none;
            display: block;
            padding: 10px;
            border-radius: 4px;
            transition: background 0.3s;
        }

        .sidebar a:hover {
            background-color: #34495e;
        }

        .main-content {
            flex: 1;
            padding: 20px;
            margin-left: 250px;
        }

        .form-container {
            max-width: 600px;
            margin: 20px auto;
            background: white;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #333;
        }

        input[type="text"],
        input[type="number"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
        }

        textarea {
            min-height: 120px;
            resize: vertical;
        }

        button {
            background-color: #27ae60;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s;
            width: 100%;
        }

        button:hover {
            background-color: #219653;
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            border: 1px solid transparent;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border-color: #c3e6cb;
        }

        h1 {
            color: #2c3e50;
            margin-top: 0;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="createtask.php" class="active">Create Task</a></li>
            <li><a href="approvetask.php">Approve Tasks</a></li>
            <li><a href="users.php">Manage Users</a></li>
            <li><a href="withdrawals.php">Withdrawals</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="form-container">
            <h1>Create New Task</h1>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>

            <form method="POST">
                <div class="form-group">
                    <label for="task_type">Task Type</label>
                    <select name="task_type" id="task_type" required>
                        <option value="">Select Task Type</option>
                        <option value="Social Media" <?= isset($_POST['task_type']) && $_POST['task_type'] == 'Social Media' ? 'selected' : '' ?>>Social Media</option>
                        <option value="Website Visit" <?= isset($_POST['task_type']) && $_POST['task_type'] == 'Website Visit' ? 'selected' : '' ?>>Website Visit</option>
                        <option value="App Download" <?= isset($_POST['task_type']) && $_POST['task_type'] == 'App Download' ? 'selected' : '' ?>>App Download</option>
                        <option value="Survey" <?= isset($_POST['task_type']) && $_POST['task_type'] == 'Survey' ? 'selected' : '' ?>>Survey</option>
                        <option value="Other" <?= isset($_POST['task_type']) && $_POST['task_type'] == 'Other' ? 'selected' : '' ?>>Other</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="title">Task Title</label>
                    <input type="text" name="title" id="title" required 
                           value="<?= isset($_POST['title']) ? htmlspecialchars($_POST['title']) : '' ?>">
                </div>

                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea name="description" id="description" rows="5" required><?= isset($_POST['description']) ? htmlspecialchars($_POST['description']) : '' ?></textarea>
                </div>

                <div class="form-group">
                    <label for="amount">Amount ($)</label>
                    <input type="number" name="amount" id="amount" step="0.01" min="0.01" required 
                           value="<?= isset($_POST['amount']) ? htmlspecialchars($_POST['amount']) : '' ?>">
                </div>

                <button type="submit">Create Task</button>
            </form>
        </div>
    </div>
</body>
</html>