<?php
// dashboard.php
session_start();

// Redirect to login if admin is not logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Include database connection
include 'db_connection.php';

// Fetch statistics for the dashboard
$total_users = $conn->query("SELECT COUNT(*) as total FROM users")->fetch_assoc()['total'];
$total_tasks = $conn->query("SELECT COUNT(*) as total FROM available_tasks")->fetch_assoc()['total'];
$total_payments = $conn->query("SELECT SUM(amount) as total FROM users")->fetch_assoc()['total'];
$total_withdrawals = $conn->query("SELECT SUM(amount) as total FROM withdrawals")->fetch_assoc()['total'];

// Remove the last_activity column check
// If you want to track active users, you'll need to add a last_activity column to the users table
$active_users = 0;
$inactive_users = $total_users;

// Fetch recent users with formatted time
$recent_users = $conn->query("SELECT id, username, email, created_at FROM users ORDER BY created_at DESC LIMIT 5");

$conn->close();

// Function to format time in EAT (East Africa Time)
function formatEAT($datetime) {
    $date = new DateTime($datetime, new DateTimeZone('UTC'));
    $date->setTimezone(new DateTimeZone('Africa/Nairobi'));
    return $date->format ('M j g:iA');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <!-- Sidebar with close button -->
    <div class="sidebar">

        <h2>Admin Panel</h2>
                <span class="sidebar-close" onclick="toggleSidebar()">&times;</span>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="creattask.php">Create Task</a></li>
            <li><a href="approvetask.php">Approve Task</a></li>
            <li><a href="users.php">Manage Users</a></li>
            <li><a href="withdrawals.php">Withdrawals</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="header">
            <div class="menu-icon" onclick="toggleSidebar()">
                <div class="bar1"></div>
                <div class="bar2"></div>
                <div class="bar3"></div>
            </div>
            <h1>Dashboard</h1>
            <form action="logout.php" method="POST">
                <button type="submit" class="logout-btn">Logout</button>
            </form>
        </div>

        <!-- Statistics Cards -->
        <div class="stats">
            <div class="stat-card">
                <h3>Total Users</h3>
                <p><?php echo $total_users; ?></p>
            </div>
            <div class="stat-card">
                <h3>Total Tasks</h3>
                <p><?php echo $total_tasks; ?></p>
            </div>
            <div class="stat-card">
                <h3>Total Payments</h3>
                <p>$<?php echo number_format($total_payments, 2); ?></p>
            </div>
            <div class="stat-card">
                <h3>Total Withdrawals</h3>
                <p>$<?php echo number_format($total_withdrawals, 2); ?></p>
            </div>
        </div>

        <!-- Recent Users Table -->
        <div class="table-container">
            <h2>Recent Users</h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Joined On</th>

                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $recent_users->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['username']; ?></td>
                            <td><?php echo $row['email']; ?></td>
                            <td><?php echo formatEAT($row['created_at']); ?></td>

                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
    function toggleSidebar() {
        const sidebar = document.querySelector('.sidebar');
        sidebar.classList.toggle('active');
        
        // Toggle body overflow when sidebar is open
        if (sidebar.classList.contains('active')) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = 'auto';
        }
    }

    // Close sidebar when clicking outside of it on mobile
    document.addEventListener('click', function(event) {
        const sidebar = document.querySelector('.sidebar');
        const menuIcon = document.querySelector('.menu-icon');
        const sidebarClose = document.querySelector('.sidebar-close');
        
        if (window.innerWidth <= 768 && 
            !sidebar.contains(event.target) && 
            !menuIcon.contains(event.target) &&
            !sidebarClose.contains(event.target)) {
            sidebar.classList.remove('active');
            document.body.style.overflow = 'auto';
        }
    });
    </script>
</body>
</html>