<?php
session_start();
// Redirect to login if not authenticated
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

include 'db_connection.php';

// Initialize variables
$error = "";
$success = "";

// Handle user status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_status') {
    $user_id = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;
    $new_status = isset($_POST['new_status']) ? (int)$_POST['new_status'] : 0;
    
    if ($user_id > 0) {
        try {
            $stmt = $conn->prepare("UPDATE users SET active_status = ? WHERE id = ?");
            $stmt->bind_param("ii", $new_status, $user_id);
            
            if ($stmt->execute()) {
                $status_text = $new_status ? "activated" : "deactivated";
                $success = "User has been $status_text successfully!";
            } else {
                $error = "Error updating user status: " . $stmt->error;
            }
            
            $stmt->close();
        } catch (Exception $e) {
            $error = "Database error: " . $e->getMessage();
        }
    } else {
        $error = "Invalid user ID!";
    }
}

// Search functionality
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$search_condition = '';
$search_params = [];

if (!empty($search)) {
    $search_condition = " WHERE username LIKE ? OR full_name LIKE ? OR email LIKE ? OR country LIKE ?";
    $search_term = "%$search%";
    $search_params = [$search_term, $search_term, $search_term, $search_term];
}

// Pagination setup
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Get total count for pagination
$count_query = "SELECT COUNT(*) as total FROM users" . $search_condition;
$count_stmt = $conn->prepare($count_query);

if (!empty($search_params)) {
    $count_stmt->bind_param(str_repeat("s", count($search_params)), ...$search_params);
}

$count_stmt->execute();
$count_result = $count_stmt->get_result();
$row = $count_result->fetch_assoc();
$total_records = $row['total'];
$total_pages = ceil($total_records / $per_page);
$count_stmt->close();

// Get users with pagination
$query = "SELECT id, username, full_name, email, phone_number, country, 
          created_at, amount, active_status
          FROM users" . $search_condition . " 
          ORDER BY created_at DESC
          LIMIT ? OFFSET ?";

$stmt = $conn->prepare($query);

if (!empty($search_params)) {
    $param_types = str_repeat("s", count($search_params)) . "ii";
    $stmt->bind_param($param_types, ...array_merge($search_params, [$per_page, $offset]));
} else {
    $stmt->bind_param("ii", $per_page, $offset);
}

$stmt->execute();
$result = $stmt->get_result();

// Get user statistics
$stats_query = "SELECT 
                    COUNT(*) as total_users,
                    SUM(CASE WHEN active_status = 1 THEN 1 ELSE 0 END) as active_users,
                    SUM(amount) as total_balance
                FROM users";
$stats_result = $conn->query($stats_query);
$stats = $stats_result->fetch_assoc();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
/* Additional dynamic styles for JavaScript functionality */
.menu-icon.change .bar1 {
    transform: rotate(-45deg) translate(-5px, 6px);
}

.menu-icon.change .bar2 {
    opacity: 0;
}

.menu-icon.change .bar3 {
    transform: rotate(45deg) translate(-5px, -6px);
}

.custom-tooltip {
    position: absolute;
    background: rgba(0, 0, 0, 0.8);
    color: white;
    padding: 5px 10px;
    border-radius: 4px;
    font-size: 12px;
    z-index: 1000;
    pointer-events: none;
}

.alert {
    transition: opacity 0.5s ease;
}

@media (max-width: 768px) {
    table.responsive {
        display: block;
        overflow-x: auto;
        white-space: nowrap;
    }
}

</style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <span class="sidebar-close" onclick="toggleSidebar()">&times;</span>
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="createtask.php">Create Task</a></li>
            <li><a href="approvetasks.php">Approve Tasks</a></li>
            <li><a href="users.php" class="active">Manage Users</a></li>
            <li><a href="withdraws.php">Withdrawals</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container">
            <div class="header">
                <div class="menu-icon" onclick="toggleSidebar()">
                    <div class="bar1"></div>
                    <div class="bar2"></div>
                    <div class="bar3"></div>
                </div>
                <h1>Manage Users</h1>
                <form action="logout.php" method="POST">
                    <button type="submit" class="logout-btn">Logout</button>
                </form>
            </div>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <!-- Statistics Cards -->
            <div class="stats">
                <div class="stat-card">
                    <h3>Total Users</h3>
                    <p><?php echo number_format($stats['total_users']); ?></p>
                
                </div>
                <div class="stat-card">
                    <h3>Total Balance</h3>
                    <p>$<?php echo number_format($stats['total_balance'], 2); ?></p>
                </div>
                                <div class="stat-card">
                    <h3>active users</h3>
                    <p><?php echo number_format($stats['active_users']); ?> </p>
                </div>
                                <div class="stat-card">
                    <h3>inactive users</h3>
                    <p> <?php echo number_format($stats['total_users'] - $stats['active_users']); ?> </p>
                </div>
            </div>

            <!-- Search Bar -->
            <form method="GET" action="" class="search-bar">
                <input type="text" name="search" placeholder="Search by username, name, email or country..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit">Search</button>
            </form>

            <!-- Users Table -->
            <div class="table-container">
                <?php if ($result->num_rows > 0): ?>
                    <h2>User List</h2>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Username</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Country</th>
                                <th>Balance</th>
                                <th>Joined</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                                    <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                                    <td><?php echo htmlspecialchars($row['country'] ?? 'N/A'); ?></td>
                                    <td>$<?php echo number_format($row['amount'], 2); ?></td>
                                    <td><?php echo date("M j, Y", strtotime($row['created_at'])); ?></td>
                                    <td class="status-cell">
                                        <i class="fas fa-circle <?php echo $row['active_status'] ? 'active-star' : 'inactive-star'; ?>"></i>
                                    </td>
                                    <td>
                                        <a href="view_user.php?id=<?php echo $row['id']; ?>" class="action-btn btn-view">View</a>
                                        
                                        <form method="POST" style="display:inline;">
                                            <input type="hidden" name="action" value="toggle_status">
                                            <input type="hidden" name="user_id" value="<?php echo $row['id']; ?>">
                                            
                                            <?php if ($row['active_status']): ?>
                                                <input type="hidden" name="new_status" value="0">
                                                <button type="submit" class="action-btn btn-deactivate">Deactivate</button>
                                            <?php else: ?>
                                                <input type="hidden" name="new_status" value="1">
                                                <button type="submit" class="action-btn btn-activate">Activate</button>
                                            <?php endif; ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    
                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="?page=<?php echo ($page - 1); ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">&laquo;</a>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <a href="?page=<?php echo $i; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>" <?php echo ($i == $page) ? 'class="active"' : ''; ?>><?php echo $i; ?></a>
                            <?php endfor; ?>
                            
                            <?php if ($page < $total_pages): ?>
                                <a href="?page=<?php echo ($page + 1); ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">&raquo;</a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    
                <?php else: ?>
                    <div class="no-users">
                        <h3>No users found</h3>
                        <?php if (!empty($search)): ?>
                            <p>No results matching your search criteria.</p>
                            <p><a href="manage_users.php">Clear search</a></p>
                        <?php else: ?>
                            <p>There are no users in the system yet.</p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script>
// Toggle sidebar function
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('active');
    
    // Toggle body scroll when sidebar is open
    if (sidebar.classList.contains('active')) {
        document.body.style.overflow = 'hidden';
    } else {
        document.body.style.overflow = 'auto';
    }
    
    // Toggle menu icon animation
    const menuIcon = document.querySelector('.menu-icon');
    menuIcon.classList.toggle('change');
}

// Close sidebar when clicking outside on mobile
document.addEventListener('click', function(event) {
    const sidebar = document.querySelector('.sidebar');
    const menuIcon = document.querySelector('.menu-icon');
    const sidebarClose = document.querySelector('.sidebar-close');
    
    if (window.innerWidth <= 768 && 
        !sidebar.contains(event.target) && 
        !menuIcon.contains(event.target) &&
        !sidebarClose.contains(event.target)) {
        sidebar.classList.remove('active');
        document.body.style.overflow = 'auto';
        document.querySelector('.menu-icon').classList.remove('change');
    }
});

// Confirm user deactivation
document.addEventListener('DOMContentLoaded', function() {
    // Deactivation confirmation
    const deactivateBtns = document.querySelectorAll('.btn-deactivate');
    
    deactivateBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to deactivate this user?')) {
                e.preventDefault();
            }
        });
    });
    
    // Activate all deactivate buttons in the page
    const activateBtns = document.querySelectorAll('.btn-activate');
    
    activateBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to activate this user?')) {
                e.preventDefault();
            }
        });
    });
    
    // Search functionality enhancement
    const searchForm = document.querySelector('.search-bar');
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            const searchInput = this.querySelector('input[name="search"]');
            if (searchInput.value.trim() === '') {
                e.preventDefault();
                alert('Please enter a search term');
            }
        });
    }
    
    // Pagination active link styling
    const paginationLinks = document.querySelectorAll('.pagination a');
    paginationLinks.forEach(link => {
        if (link.classList.contains('active')) {
            link.style.cursor = 'default';
            link.addEventListener('click', (e) => e.preventDefault());
        }
    });
    
    // Responsive table adjustments
    function handleTableResponsive() {
        const tables = document.querySelectorAll('table');
        tables.forEach(table => {
            if (window.innerWidth < 768) {
                table.classList.add('responsive');
            } else {
                table.classList.remove('responsive');
            }
        });
    }
    
    // Initial check and window resize listener
    handleTableResponsive();
    window.addEventListener('resize', handleTableResponsive);
    
    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });
    
    // Prevent form resubmission on page refresh
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
});

// Additional utility functions
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
}

// Initialize tooltips
function initTooltips() {
    const tooltipElems = document.querySelectorAll('[data-tooltip]');
    tooltipElems.forEach(elem => {
        elem.addEventListener('mouseenter', showTooltip);
        elem.addEventListener('mouseleave', hideTooltip);
    });
    
    function showTooltip(e) {
        const tooltipText = this.getAttribute('data-tooltip');
        const tooltip = document.createElement('div');
        tooltip.className = 'custom-tooltip';
        tooltip.textContent = tooltipText;
        document.body.appendChild(tooltip);
        
        const rect = this.getBoundingClientRect();
        tooltip.style.left = `${rect.left + rect.width/2 - tooltip.offsetWidth/2}px`;
        tooltip.style.top = `${rect.top - tooltip.offsetHeight - 5}px`;
    }
    
    function hideTooltip() {
        const tooltip = document.querySelector('.custom-tooltip');
        if (tooltip) tooltip.remove();
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initTooltips();
    
    // Add click event to all status cells to toggle user status
    const statusCells = document.querySelectorAll('.status-cell');
    statusCells.forEach(cell => {
        cell.addEventListener('click', function() {
            const form = this.closest('tr').querySelector('form');
            if (form) {
                form.submit();
            }
        });
    });
});
</script>


</body>
</html>
