<?php
session_start();
// Redirect to login if not authenticated
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

include 'db_connection.php';

// Initialize variables
$error = "";
$success = "";

// Function to send email notification
function sendWithdrawalEmail($email, $name, $amount, $status, $payment_method = '') {
    $subject = "Your Withdrawal Request Has Been " . ucfirst($status);
    
    $message = '
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #4a6baf; color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; background: #f9f9f9; }
            .status {
                padding: 10px;
                border-radius: 4px;
                font-weight: bold;
                text-align: center;
                margin: 15px 0;
            }
            .approved { background-color: #d4edda; color: #155724; }
            .rejected { background-color: #f8d7da; color: #721c24; }
            .footer { padding: 10px; text-align: center; font-size: 12px; color: #777; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Withdrawal Update</h1>
            </div>
            <div class="content">
                <p>Hello '.$name.',</p>
                
                <p>Your withdrawal request has been processed with the following details:</p>
                
                <table style="width: 100%; border-collapse: collapse; margin: 15px 0;">
                    <tr>
                        <td style="padding: 8px; border: 1px solid #ddd; width: 30%;"><strong>Amount:</strong></td>
                        <td style="padding: 8px; border: 1px solid #ddd;">$'.number_format($amount, 2).'</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border: 1px solid #ddd;"><strong>Payment Method:</strong></td>
                        <td style="padding: 8px; border: 1px solid #ddd;">'.$payment_method.'</td>
                    </tr>
                    <tr>
                        <td style="padding: 8px; border: 1px solid #ddd;"><strong>Status:</strong></td>
                        <td style="padding: 8px; border: 1px solid #ddd;">
                            <span class="status '.$status.'">'.ucfirst($status).'</span>
                        </td>
                    </tr>
                </table>
                
                '.($status == 'approved' ? 
                    '<p>Your funds should arrive according to your payment method\'s processing time.</p>' : 
                    '<p>The funds have been returned to your account balance.</p>').'
                
                <p>If you have any questions, please contact our support team.</p>
            </div>
            <div class="footer">
                <p>&copy; '.date('Y').' Outlier. All rights reserved.</p>
            </div>
        </div>
    </body>
    </html>';

    $headers = [
        'From' => 'Outlier <info@techhubke.site>',
        'Reply-To' => 'support@techhubke.site',
        'Content-Type' => 'text/html; charset=UTF-8',
        'X-Mailer' => 'PHP/' . phpversion()
    ];

    $headerString = '';
    foreach ($headers as $key => $value) {
        $headerString .= "$key: $value\r\n";
    }

    return mail($email, $subject, $message, $headerString);
}

// Handle withdrawal status update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $withdrawal_id = isset($_POST['withdrawal_id']) ? (int)$_POST['withdrawal_id'] : 0;
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    
    if (empty($withdrawal_id) || !in_array($action, ['approve', 'reject'])) {
        $error = "Invalid request parameters!";
    } else {
        try {
            // Begin transaction
            $conn->begin_transaction();
            
            // Get withdrawal information first
            $get_withdrawal = $conn->prepare("
                SELECT w.user_id, w.amount, w.status, w.payment_method, 
                       u.email, u.full_name, u.username
                FROM withdrawals w
                JOIN users u ON w.user_id = u.id
                WHERE w.id = ?
            ");
            $get_withdrawal->bind_param("i", $withdrawal_id);
            $get_withdrawal->execute();
            $withdrawal_result = $get_withdrawal->get_result();
            
            if ($withdrawal_row = $withdrawal_result->fetch_assoc()) {
                // Check if withdrawal is still pending
                if ($withdrawal_row['status'] !== 'pending') {
                    $error = "This withdrawal has already been processed!";
                    $conn->rollback();
                } else {
                    $new_status = $action === 'approve' ? 'approved' : 'rejected';
                    
                    // Update withdrawal status
                    $update_withdrawal = $conn->prepare("
                        UPDATE withdrawals 
                        SET status = ?, processed_by = ?, updated_at = CURRENT_TIMESTAMP 
                        WHERE id = ?
                    ");
                    $update_withdrawal->bind_param("sii", $new_status, $_SESSION['admin_id'], $withdrawal_id);
                    $update_withdrawal->execute();
                    
                    // If rejected, return the funds to user's balance
                    if ($action === 'reject') {
                        $update_user = $conn->prepare("
                            UPDATE users 
                            SET amount = amount + ? 
                            WHERE id = ?
                        ");
                        $update_user->bind_param("di", $withdrawal_row['amount'], $withdrawal_row['user_id']);
                        $update_user->execute();
                    }
                    
                    // Commit transaction
                    $conn->commit();
                    
                    // Send email notification
                    sendWithdrawalEmail(
                        $withdrawal_row['email'],
                        $withdrawal_row['full_name'],
                        $withdrawal_row['amount'],
                        $new_status,
                        $withdrawal_row['payment_method']
                    );
                    
                    $action_text = $action === 'approve' ? 'approved' : 'rejected';
                    $success = "Withdrawal has been $action_text successfully! Email notification sent to user.";
                }
            } else {
                $error = "Withdrawal not found!";
                $conn->rollback();
            }
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            $error = "Database error: " . $e->getMessage();
        }
    }
}
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
$where_clause = '';
$params = [];

if ($status_filter !== 'all' && in_array($status_filter, ['pending', 'approved', 'rejected'])) {
    $where_clause = " WHERE w.status = ?";
    $params[] = $status_filter;
}

// Pagination setup
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Get total count for pagination
$count_query = "SELECT COUNT(*) as total FROM withdrawals w" . $where_clause;
$count_stmt = $conn->prepare($count_query);

if (!empty($params)) {
    $count_stmt->bind_param(str_repeat("s", count($params)), ...$params);
}

$count_stmt->execute();
$count_result = $count_stmt->get_result();
$row = $count_result->fetch_assoc();
$total_records = $row['total'];
$total_pages = ceil($total_records / $per_page);
$count_stmt->close();

// Get withdrawals with user details
$query = "SELECT w.id, w.amount, w.payment_method, w.status, w.created_at, w.updated_at,
          u.id as user_id, u.username, u.full_name, u.email
          FROM withdrawals w
          JOIN users u ON w.user_id = u.id" . 
          $where_clause . "
          ORDER BY 
            CASE 
                WHEN w.status = 'pending' THEN 1
                WHEN w.status = 'approved' THEN 2
                WHEN w.status = 'rejected' THEN 3
            END,
            w.created_at DESC
          LIMIT ? OFFSET ?";

$stmt = $conn->prepare($query);

if (!empty($params)) {
    $param_types = str_repeat("s", count($params)) . "ii";
    $stmt->bind_param($param_types, ...array_merge($params, [$per_page, $offset]));
} else {
    $stmt->bind_param("ii", $per_page, $offset);
}

$stmt->execute();
$result = $stmt->get_result();

// Get withdrawal statistics
$stats_query = "SELECT 
                    COUNT(*) as total_withdrawals,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_withdrawals,
                    SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved_withdrawals,
                    SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected_withdrawals,
                    SUM(CASE WHEN status = 'pending' THEN amount ELSE 0 END) as pending_amount,
                    SUM(CASE WHEN status = 'approved' THEN amount ELSE 0 END) as approved_amount
                FROM withdrawals";
$stats_result = $conn->query($stats_query);
$stats = $stats_result->fetch_assoc();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Withdrawals</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
        }

        .sidebar {
            width: 250px;
            background-color: #333;
            color: #fff;
            height: 100vh;
            padding: 20px;
        }

        .sidebar h2 {
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style-type: none;
            padding: 0;
        }

        .sidebar ul li {
            margin-bottom: 10px;
        }

        .sidebar ul li a {
            color: #fff;
            text-decoration: none;
            display: block;
            padding: 8px;
            border-radius: 4px;
        }

        .sidebar ul li a:hover, .sidebar ul li a.active {
            background-color: #555;
        }

        .main-content {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        .alert {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }

        .stats-container {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .stat-card {
            flex: 1;
            min-width: 150px;
            background-color: #fff;
            border-radius: 8px;
            padding: 15px;
            margin: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            text-align: center;
        }

        .stat-card h3 {
            margin-top: 0;
            color: #333;
            font-size: 16px;
        }

        .stat-card .stat-value {
            font-size: 24px;
            font-weight: bold;
        }

        .stat-pending { color: #ffc107; }
        .stat-approved { color: #28a745; }
        .stat-rejected { color: #dc3545; }
        .stat-total { color: #007bff; }

        .filter-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }

        .filter-bar .status-filter {
            display: flex;
        }

        .filter-bar .status-filter a {
            padding: 8px 16px;
            margin-right: 5px;
            text-decoration: none;
            color: #333;
            border-radius: 4px;
            background-color: #f1f1f1;
        }

        .filter-bar .status-filter a.active {
            background-color: #007bff;
            color: white;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #f8f9fa;
            font-weight: bold;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .withdrawal-status {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }

        .status-pending {
            background-color: #fff3cd;
            color: #856404;
        }

        .status-approved {
            background-color: #d4edda;
            color: #155724;
        }

        .status-rejected {
            background-color: #f8d7da;
            color: #721c24;
        }

        .action-btn {
            display: inline-block;
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            text-align: center;
            color: white;
            margin-right: 5px;
        }

        .btn-approve {
            background-color: #28a745;
        }

        .btn-reject {
            background-color: #dc3545;
        }

        .btn-view {
            background-color: #17a2b8;
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .pagination a {
            color: #333;
            padding: 8px 16px;
            text-decoration: none;
            border: 1px solid #ddd;
            margin: 0 4px;
        }

        .pagination a.active {
            background-color: #007bff;
            color: white;
            border: 1px solid #007bff;
        }

        .pagination a:hover:not(.active) {
            background-color: #ddd;
        }

        .no-withdrawals {
            text-align: center;
            padding: 50px 0;
            color: #666;
        }

        .user-link {
            color: #007bff;
            text-decoration: none;
        }

        .user-link:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .stats-container {
                flex-direction: column;
            }
            
            .stat-card {
                margin-bottom: 10px;
            }
            
            .filter-bar {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .filter-bar .status-filter {
                margin-bottom: 10px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Admin Panel</h2>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="create_task.php">Create Task</a></li>
            <li><a href="approve_tasks.php">Approve Tasks</a></li>
            <li><a href="manage_users.php">Manage Users</a></li>
            <li><a href="withdrawals.php" class="active">Withdrawals</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container">
            <h1>Manage Withdrawals</h1>
            
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <!-- Statistics Cards -->
            <div class="stats-container">
                <div class="stat-card">
                    <h3>Total Withdrawals</h3>
                    <div class="stat-value stat-total"><?php echo number_format($stats['total_withdrawals']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Pending</h3>
                    <div class="stat-value stat-pending"><?php echo number_format($stats['pending_withdrawals']); ?></div>
                    <div>$<?php echo number_format($stats['pending_amount'], 2); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Approved</h3>
                    <div class="stat-value stat-approved"><?php echo number_format($stats['approved_withdrawals']); ?></div>
                    <div>$<?php echo number_format($stats['approved_amount'], 2); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Rejected</h3>
                    <div class="stat-value stat-rejected"><?php echo number_format($stats['rejected_withdrawals']); ?></div>
                </div>
            </div>

            <!-- Filter Bar -->
            <div class="filter-bar">
                <div class="status-filter">
                    <a href="withdrawals.php" <?php echo $status_filter === 'all' ? 'class="active"' : ''; ?>>All</a>
                    <a href="withdrawals.php?status=pending" <?php echo $status_filter === 'pending' ? 'class="active"' : ''; ?>>Pending</a>
                    <a href="withdrawals.php?status=approved" <?php echo $status_filter === 'approved' ? 'class="active"' : ''; ?>>Approved</a>
                    <a href="withdrawals.php?status=rejected" <?php echo $status_filter === 'rejected' ? 'class="active"' : ''; ?>>Rejected</a>
                </div>
            </div>

            <!-- Withdrawals Table -->
            <?php if ($result->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>User</th>
                            <th>Amount</th>
                            <th>Payment Method</th>
                            <th>Request Date</th>
                            <th>Last Updated</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td>
                                    <a href="view_user.php?id=<?php echo $row['user_id']; ?>" class="user-link">
                                        <?php echo htmlspecialchars($row['username']); ?>
                                    </a>
                                    <div><?php echo htmlspecialchars($row['email']); ?></div>
                                </td>
                                <td>$<?php echo number_format($row['amount'], 2); ?></td>
                                <td><?php echo htmlspecialchars($row['payment_method']); ?></td>
                                <td><?php echo date("M j, Y, g:i a", strtotime($row['created_at'])); ?></td>
                                <td><?php echo date("M j, Y, g:i a", strtotime($row['updated_at'])); ?></td>
                                <td>
                                    <span class="withdrawal-status status-<?php echo $row['status']; ?>">
                                        <?php echo ucfirst($row['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($row['status'] === 'pending'): ?>
                                        <form method="POST" style="display:inline;">
                                            <input type="hidden" name="withdrawal_id" value="<?php echo $row['id']; ?>">
                                            <input type="hidden" name="action" value="approve">
                                            <button type="submit" class="action-btn btn-approve">Approve</button>
                                        </form>
                                        
                                        <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to reject this withdrawal? The funds will be returned to the user\'s balance.')">
                                            <input type="hidden" name="withdrawal_id" value="<?php echo $row['id']; ?>">
                                            <input type="hidden" name="action" value="reject">
                                            <button type="submit" class="action-btn btn-reject">Reject</button>
                                        </form>
                                    <?php else: ?>
                                        <span>Processed</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
                
                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?php echo ($page - 1); ?><?php echo $status_filter !== 'all' ? '&status=' . $status_filter : ''; ?>">&laquo;</a>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <a href="?page=<?php echo $i; ?><?php echo $status_filter !== 'all' ? '&status=' . $status_filter : ''; ?>" <?php echo ($i == $page) ? 'class="active"' : ''; ?>><?php echo $i; ?></a>
                        <?php endfor; ?>
                        
                        <?php if ($page < $total_pages): ?>
                            <a href="?page=<?php echo ($page + 1); ?><?php echo $status_filter !== 'all' ? '&status=' . $status_filter : ''; ?>">&raquo;</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                
            <?php else: ?>
                <div class="no-withdrawals">
                    <h3>No withdrawals found</h3>
                    <?php if ($status_filter !== 'all'): ?>
                        <p>No <?php echo $status_filter; ?> withdrawals at the moment.</p>
                        <p><a href="withdrawals.php">View all withdrawals</a></p>
                    <?php else: ?>
                        <p>There are no withdrawal requests in the system yet.</p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>