<?php
// Database connection parameters
$servername = "localhost";
$username = "techhubk_users"; // Default username for MySQL
$password = "B9pbsqkDPNeJYgjkPcVs"; // Default password for MySQL (empty for XAMPP)
$dbname = "techhubk_users"; // Name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Optionally, you can set the charset to utf8mb4 for better support of special characters
$conn->set_charset("utf8mb4");

// You can now include this file in other PHP scripts to use the $conn variable for database operations
?>