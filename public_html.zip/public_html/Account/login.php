<?php
session_start();
require_once 'db_connect.php';

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Fetch user from the database including activation status
    $stmt = $conn->prepare("SELECT id, password, active_status, full_name FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['full_name'] = $row['full_name'];

            // Check account activation status
            if ($row['active_status'] == 1) {
                header("Location: dashboard.php");
                exit();
            } else {
                // Store user ID in session for activation process
                $_SESSION['pending_activation'] = $row['id'];
                header("Location: activation_pending.php");
                exit();
            }
        } else {
            $error_message = "Invalid email or password.";
        }
    } else {
        $error_message = "Invalid email or password.";
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Outlier - Login</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        .container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 30px;
            width: 100%;
            max-width: 400px;
            text-align: center;
        }
        .logo {
            width: 100px;
            margin-bottom: 20px;
        }
        h1 {
            color: #333;
            margin-bottom: 10px;
        }
        p {
            color: #666;
            margin-bottom: 20px;
        }
        .input-container {
            margin-bottom: 15px;
            position: relative;
        }
        input {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
        }
        .password-container {
            position: relative;
        }
        #togglePassword {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #666;
        }
        button {
            background-color: #4a6baf;
            color: white;
            border: none;
            padding: 12px;
            width: 100%;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background-color: #3a5a9f;
        }
        .links {
            margin-top: 20px;
            font-size: 14px;
        }
        a {
            color: #4a6baf;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .error-message {
            background-color: #fff0f0;
            color: #e74c3c;
            border-left: 4px solid #e74c3c;
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 4px;
            text-align: left;
            font-size: 14px;
        }
        .footer {
            margin-top: 30px;
            font-size: 12px;
            color: #999;
        }
    </style>
</head>
<body>
    <div class="container">
        <img src="logo.jpeg" alt="Outlier Logo" class="logo">
        <h1>Login</h1>
        <p>Welcome back! Please sign in to continue.</p>

        <?php if (!empty($error_message)): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <form action="login.php" method="POST">
            <div class="input-container">
                <input type="email" name="email" placeholder="Email" required>
            </div>
            
            <div class="input-container password-container">
                <input type="password" id="password" name="password" placeholder="Password" required>
                <span id="togglePassword">
                    <i class="fas fa-eye"></i>
                </span>
            </div>

            <div style="text-align: right; margin-bottom: 15px;">
                <a href="forgot_password.php">Forgot password?</a>
            </div>

            <button type="submit">Sign in</button>
        </form>

        <div class="links">
            Don't have an account? <a href="register.php">Sign up</a>
        </div>

        <div class="footer">
            Outlier © <?php echo date('Y'); ?> | 
            <a href="terms.php">Terms and Conditions</a>
        </div>
    </div>

    <script>
        // Toggle Password Visibility
        const togglePassword = document.querySelector('#togglePassword');
        const password = document.querySelector('#password');

        togglePassword.addEventListener('click', function () {
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            
            this.querySelector('i').classList.toggle('fa-eye');
            this.querySelector('i').classList.toggle('fa-eye-slash');
        });
    </script>
</body>
</html>