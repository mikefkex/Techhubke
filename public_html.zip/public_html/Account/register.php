<?php
session_start();
require_once 'db_connect.php';

function generateToken() {
    return bin2hex(random_bytes(32));
}

function sendActivationEmail($email, $name, $token) {
    $activationLink = "https://mpesapay.techhubke.site/activate.php?token=$token";
    $subject = "Activate Your Outlier Account";
    
    $message = '
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #4a6baf; color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; background: #f9f9f9; }
            .button { 
                background: #4a6baf; color: white; 
                padding: 10px 20px; text-decoration: none; 
                display: inline-block; border-radius: 4px; 
                margin: 15px 0;
            }
            .footer { padding: 10px; text-align: center; font-size: 12px; color: #777; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Welcome to Outlier</h1>
            </div>
            <div class="content">
                <p>Hello '.$name.',</p>
                <p>Thank you for registering! Please click the button below to activate your account:</p>
                <a href="'.$activationLink.'" class="button">Activate Account</a>
                <p>This link will expire in 24 hours.</p>
                <p>If you didn\'t request this, please ignore this email.</p>
            </div>
            <div class="footer">
                <p>&copy; '.date('Y').' Outlier. All rights reserved.</p>
            </div>
        </div>
    </body>
    </html>';

    $headers = [
        'From' => 'Outlier <info@techhubke.site>',
        'Reply-To' => 'info@techhubke.site',
        'Content-Type' => 'text/html; charset=UTF-8',
        'X-Mailer' => 'PHP/' . phpversion()
    ];

    $headerString = '';
    foreach ($headers as $key => $value) {
        $headerString .= "$key: $value\r\n";
    }

    return mail($email, $subject, $message, $headerString);
}

$error_message = "";
$input_values = [];
$valid = true;
$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize inputs
    $username = trim(htmlspecialchars($_POST['username'] ?? ''));
    $full_name = trim(htmlspecialchars($_POST['full_name'] ?? ''));
    $email = trim(htmlspecialchars($_POST['email'] ?? ''));
    $phone_number = trim(htmlspecialchars($_POST['phone_number'] ?? ''));
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirmPassword'] ?? '';
    $country = $_POST['country'] ?? '';
    $referral_source = trim(htmlspecialchars($_POST['referral_source'] ?? ''));

    // Store input values
    $input_values = compact('username', 'full_name', 'email', 'phone_number', 'country', 'referral_source');

    // Validation
    if (empty($username)) $errors[] = "Username is required";
    if (empty($full_name)) $errors[] = "Full name is required";
    if (empty($email)) $errors[] = "Email is required";
    if (empty($password)) $errors[] = "Password is required";
    if (empty($country)) $errors[] = "Country is required";
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format";
    if (strlen($password) < 8) $errors[] = "Password must be at least 8 characters";
    if (!preg_match('/[A-Z]/', $password)) $errors[] = "Password needs at least one uppercase letter";
    if (!preg_match('/[a-z]/', $password)) $errors[] = "Password needs at least one lowercase letter";
    if (!preg_match('/[0-9]/', $password)) $errors[] = "Password needs at least one number";
    if ($password !== $confirm_password) $errors[] = "Passwords don't match";

    if (empty($errors)) {
        try {
            $conn->begin_transaction();

            // Check if username or email exists
            $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->bind_param("ss", $username, $email);
            $stmt->execute();
            
            if ($stmt->get_result()->num_rows > 0) {
                throw new Exception("Username or email already exists");
            }

            // Hash password and generate token
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $activation_token = generateToken();
            $token_expires = date('Y-m-d H:i:s', strtotime('+24 hours'));

            // Insert user
            $stmt = $conn->prepare("INSERT INTO users (username, full_name, email, phone_number, password, country, referral_source, activation_token, token_expires_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("sssssssss", $username, $full_name, $email, $phone_number, $hashed_password, $country, $referral_source, $activation_token, $token_expires);
            
            if (!$stmt->execute()) {
                throw new Exception("Registration failed");
            }

            $user_id = $stmt->insert_id;

            // Store verification record
            $stmt = $conn->prepare("INSERT INTO email_verifications (user_id, token, expires_at) VALUES (?, ?, ?)");
            $stmt->bind_param("iss", $user_id, $activation_token, $token_expires);
            $stmt->execute();

            // Send activation email
            if (!sendActivationEmail($email, $full_name, $activation_token)) {
                throw new Exception("Failed to send activation email");
            }

            $conn->commit();
            
            $_SESSION['success_message'] = "Registration successful! Please check your email to activate your account.";
            header("Location: login.php");
            exit();

        } catch (Exception $e) {
            $conn->rollback();
            $error_message = $e->getMessage();
        }
    } else {
        $error_message = implode("<br>", $errors);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | Outlier</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary: #4a6baf;
            --error: #e74c3c;
            --success: #27ae60;
        }
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .container {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 500px;
            padding: 2rem;
        }
        .logo {
            display: block;
            margin: 0 auto 1.5rem;
            max-width: 150px;
        }
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 1rem;
        }
        p.subtitle {
            text-align: center;
            color: #666;
            margin-bottom: 2rem;
        }
        .error-message {
            background: #ffebee;
            color: var(--error);
            border-left: 4px solid var(--error);
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 4px;
        }
        .success-message {
            background: #e8f5e9;
            color: var(--success);
            border-left: 4px solid var(--success);
            padding: 1rem;
            margin-bottom: 1.5rem;
            border-radius: 4px;
        }
        .form-group {
            margin-bottom: 1.2rem;
        }
        label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 600;
            color: #444;
        }
        input, select {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
            box-sizing: border-box;
        }
        .password-container {
            position: relative;
        }
        .password-toggle {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #666;
        }
        .password-strength {
            height: 4px;
            background: #eee;
            margin-top: 5px;
            border-radius: 2px;
            overflow: hidden;
        }
        .password-strength-bar {
            height: 100%;
            width: 0%;
            background: var(--error);
            transition: width 0.3s, background 0.3s;
        }
        .password-hints {
            font-size: 0.85rem;
            color: #666;
            margin-top: 5px;
        }
        .password-hints ul {
            padding-left: 1.2rem;
            margin: 5px 0;
        }
        .password-hints .valid {
            color: var(--success);
        }
        .password-hints .invalid {
            color: #666;
        }
        button[type="submit"] {
            width: 100%;
            padding: 1rem;
            background: var(--primary);
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            margin-top: 1rem;
            transition: background 0.2s;
        }
        button[type="submit"]:hover {
            background: #3a5a9f;
        }
        .login-link {
            text-align: center;
            margin-top: 1.5rem;
            color: #666;
        }
        .login-link a {
            color: var(--primary);
            text-decoration: none;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
        .footer {
            text-align: center;
            margin-top: 2rem;
            color: #999;
            font-size: 0.85rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <img src="logo.jpeg" alt="Outlier Logo" class="logo">
        <h1>Create Account</h1>
        <p class="subtitle">Join Outlier to connect with professionals worldwide</p>

        <?php if (!empty($error_message)): ?>
            <div class="error-message"><?= $error_message ?></div>
        <?php endif; ?>

        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="success-message">
                <?= $_SESSION['success_message'] ?>
                <?php unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>

        <form method="post" action="register.php">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required 
                       value="<?= htmlspecialchars($input_values['username'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label for="full_name">Full Name</label>
                <input type="text" id="full_name" name="full_name" required
                       value="<?= htmlspecialchars($input_values['full_name'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required
                       value="<?= htmlspecialchars($input_values['email'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label for="phone_number">Phone Number (Optional)</label>
                <input type="tel" id="phone_number" name="phone_number"
                       value="<?= htmlspecialchars($input_values['phone_number'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <div class="password-container">
                    <input type="password" id="password" name="password" required>
                    <span class="password-toggle" id="togglePassword">
                        <i class="fas fa-eye"></i>
                    </span>
                </div>
                <div class="password-strength">
                    <div class="password-strength-bar" id="passwordStrength"></div>
                </div>
                <div class="password-hints" id="passwordHints">
                    <ul>
                        <li class="invalid" id="length">At least 8 characters</li>
                        <li class="invalid" id="uppercase">At least one uppercase letter</li>
                        <li class="invalid" id="lowercase">At least one lowercase letter</li>
                        <li class="invalid" id="number">At least one number</li>
                    </ul>
                </div>
            </div>

            <div class="form-group">
                <label for="confirmPassword">Confirm Password</label>
                <div class="password-container">
                    <input type="password" id="confirmPassword" name="confirmPassword" required>
                    <span class="password-toggle" id="toggleConfirmPassword">
                        <i class="fas fa-eye"></i>
                    </span>
                </div>
                <div id="passwordMatch" style="font-size:0.85rem; color:#666;"></div>
            </div>

            <div class="form-group">
                <label for="country">Country</label>
                <select id="country" name="country" required>
                    <option value="">Select Country</option>
                    <option value="US" <?= (isset($input_values['country']) && $input_values['country'] == 'US') ? 'selected' : '' ?>>United States</option>
                    <option value="CA" <?= (isset($input_values['country']) && $input_values['country'] == 'CA') ? 'selected' : '' ?>>Canada</option>
                    <option value="UK" <?= (isset($input_values['country']) && $input_values['country'] == 'UK') ? 'selected' : '' ?>>United Kingdom</option>
                    <option value="IN" <?= (isset($input_values['country']) && $input_values['country'] == 'IN') ? 'selected' : '' ?>>India</option>
                    <option value="SA" <?= (isset($input_values['country']) && $input_values['country'] == 'SA') ? 'selected' : '' ?>>South Africa</option>
                    <option value="AU" <?= (isset($input_values['country']) && $input_values['country'] == 'AU') ? 'selected' : '' ?>>Australia</option>
                    <option value="KE" <?= (isset($input_values['country']) && $input_values['country'] == 'KE') ? 'selected' : '' ?>>Kenya</option>
                </select>
            </div>

            <div class="form-group">
                <label for="referral_source">How did you hear about us? (Optional)</label>
                <input type="text" id="referral_source" name="referral_source"
                       value="<?= htmlspecialchars($input_values['referral_source'] ?? '') ?>">
            </div>

            <button type="submit">Create Account</button>
        </form>

        <div class="login-link">
            Already have an account? <a href="login.php">Sign in</a>
        </div>

        <div class="footer">
            Outlier © <?= date('Y') ?> | 
            <a href="terms.php">Terms of Service</a> | 
            <a href="privacy.php">Privacy Policy</a>
        </div>
    </div>

    <script>
        // Password toggle functionality
        const togglePassword = (toggleId, inputId) => {
            const toggle = document.getElementById(toggleId);
            const input = document.getElementById(inputId);
            
            toggle.addEventListener('click', () => {
                const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
                input.setAttribute('type', type);
                toggle.querySelector('i').classList.toggle('fa-eye');
                toggle.querySelector('i').classList.toggle('fa-eye-slash');
            });
        };

        togglePassword('togglePassword', 'password');
        togglePassword('toggleConfirmPassword', 'confirmPassword');

        // Password strength meter
        const passwordInput = document.getElementById('password');
        const strengthBar = document.getElementById('passwordStrength');
        const hints = {
            length: document.getElementById('length'),
            uppercase: document.getElementById('uppercase'),
            lowercase: document.getElementById('lowercase'),
            number: document.getElementById('number')
        };

        passwordInput.addEventListener('input', function() {
            const password = this.value;
            let strength = 0;
            
            // Check requirements
            const hasLength = password.length >= 8;
            const hasUppercase = /[A-Z]/.test(password);
            const hasLowercase = /[a-z]/.test(password);
            const hasNumber = /[0-9]/.test(password);

            // Update hints
            hints.length.classList.toggle('valid', hasLength);
            hints.length.classList.toggle('invalid', !hasLength);
            hints.uppercase.classList.toggle('valid', hasUppercase);
            hints.uppercase.classList.toggle('invalid', !hasUppercase);
            hints.lowercase.classList.toggle('valid', hasLowercase);
            hints.lowercase.classList.toggle('invalid', !hasLowercase);
            hints.number.classList.toggle('valid', hasNumber);
            hints.number.classList.toggle('invalid', !hasNumber);

            // Calculate strength
            if (hasLength) strength += 25;
            if (hasUppercase) strength += 25;
            if (hasLowercase) strength += 25;
            if (hasNumber) strength += 25;

            // Update strength bar
            strengthBar.style.width = strength + '%';
            
            if (strength < 50) {
                strengthBar.style.backgroundColor = '#e74c3c';
            } else if (strength < 100) {
                strengthBar.style.backgroundColor = '#f39c12';
            } else {
                strengthBar.style.backgroundColor = '#27ae60';
            }
        });

        // Password match checker
        const confirmPassword = document.getElementById('confirmPassword');
        const matchMessage = document.getElementById('passwordMatch');

        confirmPassword.addEventListener('input', function() {
            if (passwordInput.value !== this.value) {
                matchMessage.textContent = 'Passwords do not match';
                matchMessage.style.color = '#e74c3c';
            } else if (this.value.length > 0) {
                matchMessage.textContent = 'Passwords match';
                matchMessage.style.color = '#27ae60';
            } else {
                matchMessage.textContent = '';
            }
        });
    </script>
</body>
</html>