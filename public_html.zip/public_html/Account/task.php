<?php
// task.php
session_start();
require 'db_connect.php'; // Include your database connection file

// Redirect if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Fetch user details
$user_sql = "SELECT username, full_name, email, phone_number, country FROM users WHERE id = ?";
$user_stmt = $conn->prepare($user_sql);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();

// Fetch available tasks that the user has NOT completed
$available_tasks_sql = "SELECT at.id, at.task_type, at.description, at.amount 
                        FROM available_tasks at
                        LEFT JOIN completed_tasks ct ON at.id = ct.task_id AND ct.user_id = ?
                        WHERE ct.id IS NULL"; // Only fetch tasks not completed by the user
$available_tasks_stmt = $conn->prepare($available_tasks_sql);
$available_tasks_stmt->bind_param("i", $user_id);
$available_tasks_stmt->execute();
$available_tasks_result = $available_tasks_stmt->get_result();
$available_tasks = $available_tasks_result->fetch_all(MYSQLI_ASSOC);

// Fetch completed tasks for the logged-in user (from newest to oldest)
$completed_tasks_sql = "SELECT ct.id, at.task_type, at.description, ct.submission, ct.status, ct.created_at 
                        FROM completed_tasks ct
                        JOIN available_tasks at ON ct.task_id = at.id
                        WHERE ct.user_id = ?
                        ORDER BY ct.created_at DESC";
$completed_tasks_stmt = $conn->prepare($completed_tasks_sql);
$completed_tasks_stmt->bind_param("i", $user_id);
$completed_tasks_stmt->execute();
$completed_tasks_result = $completed_tasks_stmt->get_result();
$completed_tasks = $completed_tasks_result->fetch_all(MYSQLI_ASSOC);

// Format the time in EAT with AM/PM
foreach ($completed_tasks as &$task) {
    $date = new DateTime($task['created_at'], new DateTimeZone('UTC')); // Assume the time is stored in UTC
    $date->setTimezone(new DateTimeZone('Africa/Nairobi')); // Convert to EAT
    $task['created_at'] = $date->format('Y-m-d h:i A'); // Format as EAT with AM/PM
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Tasks</title>
    <link href="css/app.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        .error {
            color: red;
            margin-bottom: 15px;
        }
        .success {
            color: green;
            margin-bottom: 15px;
        }
        .tasks-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .tasks-table th, .tasks-table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }
        .tasks-table th {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <nav id="sidebar" class="sidebar js-sidebar">
            <div class="sidebar-content js-simplebar">
                <a class="sidebar-brand" href="index.html">
                    <span class="align-middle">Remotasker</span>
                </a>

                <ul class="sidebar-nav">
                    <li class="sidebar-header">
                        Pages
                    </li>

                    <li class="sidebar-item">
                        <a class="sidebar-link" href="dashboard.php">
                            <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
                        </a>
                    </li>

                    <li class="sidebar-item active">
                        <a class="sidebar-link" href="task.php">
                            <i class="align-middle" data-feather="award"></i> <span class="align-middle">Tasks</span>
                        </a>
                    </li>

                    <li class="sidebar-item">
                        <a class="sidebar-link" href="withdraw.php">
                            <i class="align-middle" data-feather="log-in"></i> <span class="align-middle">Withdraw</span>
                        </a>
                    </li>

                    <li class="sidebar-item">
                        <a class="sidebar-link" href="logout.php">
                            <i class="align-middle" data-feather="log-out"></i> <span class="align-middle">Logout</span>
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <div class="main">
            <nav class="navbar navbar-expand navbar-light navbar-bg">
                <a class="sidebar-toggle js-sidebar-toggle">
                    <i class="hamburger align-self-center"></i>
                </a>

                <div class="navbar-collapse collapse">
                    <ul class="navbar-nav navbar-align">
                        <li class="nav-item dropdown">
                            <a class="nav-icon dropdown-toggle" href="#" id="alertsDropdown" data-bs-toggle="dropdown">
                                <div class="position-relative">
                                    <i class="align-middle" data-feather="bell"></i>
                                    <span class="indicator">4</span>
                                </div>
                            </a>
                            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end py-0" aria-labelledby="alertsDropdown">
                                <div class="dropdown-menu-header">
                                    4 New Notifications
                                </div>

                                <div class="dropdown-menu-footer">
                                    <a href="#" class="text-muted">Show all notifications</a>
                                </div>
                            </div>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-icon dropdown-toggle" href="#" id="messagesDropdown" data-bs-toggle="dropdown">
                                <div class="position-relative">
                                    <i class="align-middle" data-feather="message-square"></i>
                                </div>
                            </a>
                            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end py-0" aria-labelledby="messagesDropdown">
                                <div class="dropdown-menu-header">
                                    <div class="position-relative">
                                        4 New Messages
                                    </div>
                                </div>

                                <div class="dropdown-menu-footer">
                                    <a href="#" class="text-muted">Show all messages</a>
                                </div>
                            </div>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#" data-bs-toggle="dropdown">
                                <img src="img/avatars/avatar.jpg" class="avatar img-fluid rounded me-1" alt="User Avatar" /> <span class="text-dark"><?php echo htmlspecialchars($user['username']); ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a class="dropdown-item" href="#"><i class="align-middle me-1" data-feather="user"></i> Profile</a>
                                <a class="dropdown-item" href="#"><i class="align-middle me-1" data-feather="settings"></i> Settings</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logout.php">Log out</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>

            <main class="content">
                <div class="container-fluid p-0">
                    <h1 class="h3 mb-3"><strong>User Tasks</strong></h1>

                    <!-- Display Error or Success Messages -->
                    <?php if ($error): ?>
                        <div class="error"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>
                    <?php if ($success): ?>
                        <div class="success"><?php echo htmlspecialchars($success); ?></div>
                    <?php endif; ?>

                    <!-- Display Available Tasks -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Available Tasks</h5>
                        </div>
                        <div class="card-body">
                            <?php if (count($available_tasks) > 0): ?>
                                <table class="tasks-table">
                                    <thead>
                                        <tr>
                                            <th>Task Type</th>
                                            <th>Description</th>
                                            <th>Amount</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($available_tasks as $task): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($task['task_type']); ?></td>
                                                <td><?php echo htmlspecialchars($task['description']); ?></td>
                                                <td>$<?php echo number_format($task['amount'], 2); ?></td>
                                                <td>
                                                    <a href="complete_task.php?task_id=<?php echo $task['id']; ?>" class="btn btn-primary">Complete Task</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <p>No available tasks found.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Display Completed Tasks -->
                    <div class="card mt-4">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Completed Tasks</h5>
                        </div>
                        <div class="card-body">
                            <?php if (count($completed_tasks) > 0): ?>
                                <table class="tasks-table">
                                    <thead>
                                        <tr>
                                            <th>Task Type</th>
                                            <th>Description</th>
                                            <th>Submission</th>
                                            <th>Status</th>
                                            <th>Completed At (EAT)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($completed_tasks as $task): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($task['task_type'] ?? 'N/A'); ?></td>
                                                <td><?php echo htmlspecialchars($task['description'] ?? 'N/A'); ?></td>
                                                <td><?php echo htmlspecialchars($task['submission'] ?? 'N/A'); ?></td>
<!-- Inside the Completed Tasks table -->
<td>
    <?php if ($task['status'] === 'pending'): ?>
        <span class="text-warning"><?php echo htmlspecialchars($task['status']); ?></span>
    <?php elseif ($task['status'] === 'approved'): ?>
        <span class="text-success"><?php echo htmlspecialchars($task['status']); ?></span>
    <?php else: ?>
        <?php echo htmlspecialchars($task['status'] ?? 'N/A'); ?>
    <?php endif; ?>
</td>
                                                <td><?php echo htmlspecialchars($task['created_at'] ?? 'N/A'); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <p>No completed tasks found.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </main>

            <footer class="footer">
                <div class="container-fluid">
                    <div class="row text-muted">
                        <div class="col-6 text-start">
                            <p class="mb-0">
                                <a class="text-muted" href="https://tecchhubke.site" target="_blank"><strong>Tecchhubke Softwares</strong></a> - <a class="text-muted" href="https://techhubke.site" target="_blank"><strong>KE</strong></a> &copy;
                            </p>
                        </div>
                        <div class="col-6 text-end">
                            <ul class="list-inline">
                                <li class="list-inline-item">
                                    <a class="text-muted" href="#" target="_blank">Support</a>
                                </li>
                                <li class="list-inline-item">
                                    <a class="text-muted" href="#" target="_blank">Help Center</a>
                                </li>
                                <li class="list-inline-item">
                                    <a class="text-muted" href="#" target="_blank">Privacy</a>
                                </li>
                                <li class="list-inline-item">
                                    <a class="text-muted" href="#" target="_blank">Terms</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <script src="js/app.js"></script>
</body>
</html>