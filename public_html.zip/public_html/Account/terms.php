<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Outlier - User Agreements</title>
    <link rel="stylesheet" href="styles.css"> <!-- Link to external CSS file -->
    <style>
        /* Basic styling for the agreements page */
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
            color: #333;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .logo {
            display: block;
            margin: 0 auto 20px;
            max-width: 150px;
        }

        h1, h2 {
            color: #2c3e50;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        h2 {
            margin-top: 30px;
            margin-bottom: 15px;
            border-bottom: 2px solid #2c3e50;
            padding-bottom: 5px;
        }

        p {
            margin-bottom: 15px;
        }

        ul {
            margin-bottom: 15px;
            padding-left: 20px;
        }

        ul li {
            margin-bottom: 10px;
        }

        .footer {
            text-align: center;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #ddd;
            color: #777;
        }

        .footer a {
            color: #2c3e50;
            text-decoration: none;
        }

        .footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Outlier Logo -->
        <img src="logo.jpeg" alt="Outlier Logo" class="logo">

        <h1>User Agreements</h1>
        <p>Welcome to Outlier! Please read these agreements carefully before using our services.</p>

        <!-- Terms and Conditions -->
        <h2>1. Terms and Conditions</h2>
        <p>By accessing or using Outlier, you agree to be bound by these terms and conditions. If you do not agree, please do not use our services.</p>
        <ul>
            <li>You must be at least 18 years old to use this platform.</li>
            <li>You are responsible for maintaining the confidentiality of your account and password.</li>
            <li>You agree not to use the platform for any illegal or unauthorized purposes.</li>
            <li>Outlier reserves the right to terminate or suspend your account at any time for violations of these terms.</li>
        </ul>

        <!-- Privacy Policy -->
        <h2>2. Privacy Policy</h2>
        <p>Your privacy is important to us. This privacy policy explains how we collect, use, and protect your personal information:</p>
        <ul>
            <li>We collect information such as your name, email address, and payment details when you register or make a payment.</li>
            <li>We use your information to provide and improve our services, process payments, and communicate with you.</li>
            <li>We do not share your personal information with third parties without your consent, except as required by law.</li>
            <li>We implement security measures to protect your data, but no method of transmission over the internet is 100% secure.</li>
        </ul>

        <!-- Community Guidelines -->
        <h2>3. Community Guidelines</h2>
        <p>To ensure a positive experience for all users, please adhere to the following community guidelines:</p>
        <ul>
            <li>Be respectful and courteous to other users.</li>
            <li>Do not post offensive, harmful, or inappropriate content.</li>
            <li>Do not engage in spamming, phishing, or other malicious activities.</li>
            <li>Report any violations of these guidelines to our support team.</li>
        </ul>

        <!-- Copyright Policy -->
        <h2>4. Copyright Policy</h2>
        <p>Outlier respects intellectual property rights. If you believe your work has been copied in a way that constitutes copyright infringement, please contact us with the following information:</p>
        <ul>
            <li>A description of the copyrighted work that you claim has been infringed.</li>
            <li>The location of the infringing material on our platform.</li>
            <li>Your contact information, including email address and phone number.</li>
            <li>A statement that you have a good faith belief that the use of the material is not authorized by the copyright owner.</li>
        </ul>

        <!-- Footer -->
        <div class="footer">
            <a href="login.php">Back to Home</a>
        </div>
    </div>
</body>
</html>