<?php
// withdraw.php
session_start();
require 'db_connect.php'; // Include your database connection file

// Redirect if the user is not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$error = '';
$success = '';

// Fetch user details
$user_sql = "SELECT username, full_name, email, phone_number, country, amount FROM users WHERE id = ?";
$user_stmt = $conn->prepare($user_sql);
$user_stmt->bind_param("i", $user_id);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();

// Handle withdrawal form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = floatval($_POST['amount']);
    $payment_method = 'mpesa'; // Default payment method

    // Validate minimum withdrawal amount
    if ($amount < 100) {
        $error = "Minimum withdrawal amount is $100.";
    } else {
        // Fetch user balance
        $user_balance = $user['amount'];

        // Check if the user has sufficient balance
        if ($user_balance < $amount) {
            $error = "Insufficient balance.";
        } else {
            // Start a transaction to ensure data consistency
            $conn->begin_transaction();

            try {
                // Insert withdrawal request
                $insert_sql = "INSERT INTO withdrawals (user_id, amount, payment_method, status) VALUES (?, ?, ?, 'pending')";
                $insert_stmt = $conn->prepare($insert_sql);
                $insert_stmt->bind_param("ids", $user_id, $amount, $payment_method);

                if ($insert_stmt->execute()) {
                    // Deduct the amount from the user's balance
                    $update_sql = "UPDATE users SET amount = amount - ? WHERE id = ?";
                    $update_stmt = $conn->prepare($update_sql);
                    $update_stmt->bind_param("di", $amount, $user_id);

                    if ($update_stmt->execute()) {
                        // Commit the transaction if both queries succeed
                        $conn->commit();
                        $success = "Withdrawal request submitted successfully!";
                    } else {
                        // Rollback the transaction if the update fails
                        $conn->rollback();
                        $error = "Error updating user balance.";
                    }
                } else {
                    // Rollback the transaction if the insert fails
                    $conn->rollback();
                    $error = "Error submitting withdrawal request.";
                }
            } catch (Exception $e) {
                // Rollback the transaction in case of any exception
                $conn->rollback();
                $error = "An error occurred. Please try again.";
            }
        }
    }
}

// Fetch all withdrawals (both pending and approved) starting with the latest
$withdrawals_sql = "SELECT amount, payment_method, status, created_at FROM withdrawals WHERE user_id = ? ORDER BY created_at DESC";
$withdrawals_stmt = $conn->prepare($withdrawals_sql);
$withdrawals_stmt->bind_param("i", $user_id);
$withdrawals_stmt->execute();
$withdrawals_result = $withdrawals_stmt->get_result();
$withdrawals = $withdrawals_result->fetch_all(MYSQLI_ASSOC);

// Format the time in EAT with AM/PM
foreach ($withdrawals as &$withdrawal) {
    $date = new DateTime($withdrawal['created_at'], new DateTimeZone('UTC')); // Assume the time is stored in UTC
    $date->setTimezone(new DateTimeZone('Africa/Nairobi')); // Convert to EAT
    $withdrawal['created_at'] = $date->format('Y-m-d h:i A'); // Format as EAT with AM/PM
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Withdraw Funds</title>
    <link href="css/app.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        .error {
            color: red;
            margin-bottom: 15px;
        }
        .success {
            color: green;
            margin-bottom: 15px;
        }
        .user-details {
            margin-top: 20px;
            padding: 15px;
            background-color: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .user-details p {
            margin: 5px 0;
        }
        .status-pending {
            color: orange;
        }
        .status-approved {
            color: green;
        }
        .status-rejected {
            color: red;
        }
    </style>
</head>
<body>
    <div class="wrapper">
        <!-- Sidebar -->
        <nav id="sidebar" class="sidebar js-sidebar">
            <div class="sidebar-content js-simplebar">
                <a class="sidebar-brand" href="index.html">
                    <span class="align-middle">Freelancer</span>
                </a>
                <ul class="sidebar-nav">
                    <li class="sidebar-header">Pages</li>
                    <li class="sidebar-item">
                        <a class="sidebar-link" href="dashboard.php">
                            <i class="align-middle" data-feather="sliders"></i> <span class="align-middle">Dashboard</span>
                        </a>
                    </li>
                    <li class="sidebar-item">
                        <a class="sidebar-link" href="task.php">
                            <i class="align-middle" data-feather="award"></i> <span class="align-middle">Tasks</span>
                        </a>
                    </li>
                    <li class="sidebar-item active">
                        <a class="sidebar-link" href="withdraw.php">
                            <i class="align-middle" data-feather="log-in"></i> <span class="align-middle">Withdraw</span>
                        </a>
                    </li>
                    <li class="sidebar-item">
                        <a class="sidebar-link" href="logout.php">
                            <i class="align-middle" data-feather="user-plus"></i> <span class="align-middle">Logout</span>
                        </a>
                    </li>
                </ul>
            </div>
        </nav>

        <div class="main">
            <!-- Navbar -->
            <nav class="navbar navbar-expand navbar-light navbar-bg">
                <a class="sidebar-toggle js-sidebar-toggle">
                    <i class="hamburger align-self-center"></i>
                </a>
                <div class="navbar-collapse collapse">
                    <ul class="navbar-nav navbar-align">
                        <li class="nav-item dropdown">
                            <a class="nav-icon dropdown-toggle" href="#" id="alertsDropdown" data-bs-toggle="dropdown">
                                <div class="position-relative">
                                    <i class="align-middle" data-feather="bell"></i>
                                    <span class="indicator">4</span>
                                </div>
                            </a>
                            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end py-0" aria-labelledby="alertsDropdown">
                                <div class="dropdown-menu-header">4 New Notifications</div>
                                <div class="dropdown-menu-footer">
                                    <a href="#" class="text-muted">Show all notifications</a>
                                </div>
                            </div>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-icon dropdown-toggle" href="#" id="messagesDropdown" data-bs-toggle="dropdown">
                                <div class="position-relative">
                                    <i class="align-middle" data-feather="message-square"></i>
                                </div>
                            </a>
                            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-end py-0" aria-labelledby="messagesDropdown">
                                <div class="dropdown-menu-header">
                                    <div class="position-relative">4 New Messages</div>
                                </div>
                                <div class="dropdown-menu-footer">
                                    <a href="#" class="text-muted">Show all messages</a>
                                </div>
                            </div>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-icon dropdown-toggle d-inline-block d-sm-none" href="#" data-bs-toggle="dropdown">
                                <i class="align-middle" data-feather="settings"></i>
                            </a>
                            <a class="nav-link dropdown-toggle d-none d-sm-inline-block" href="#" data-bs-toggle="dropdown">
                                <img src="img/avatars/avatar.jpg" class="avatar img-fluid rounded me-1" alt="User Avatar" />
                                <span class="text-dark"><?php echo htmlspecialchars($user['username']); ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end">
                                <a class="dropdown-item" href="#"><i class="align-middle me-1" data-feather="user"></i> Profile</a>
                                <a class="dropdown-item" href="#"><i class="align-middle me-1" data-feather="pie-chart"></i> Analytics</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="#"><i class="align-middle me-1" data-feather="settings"></i> Settings & Privacy</a>
                                <a class="dropdown-item" href="#"><i class="align-middle me-1" data-feather="help-circle"></i> Help Center</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="logout.php">Log out</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>

            <main class="content">
                <div class="container-fluid p-0">
                    <h1 class="h3 mb-3"><strong>Withdraw Funds</strong></h1>

                    <!-- Display Error or Success Messages -->
                    <?php if ($error): ?>
                        <div class="error"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>
                    <?php if ($success): ?>
                        <div class="success"><?php echo htmlspecialchars($success); ?></div>
                    <?php endif; ?>

                    <!-- Withdrawal Form -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">Withdraw Funds</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="">
                                <div class="mb-3">
                                    <label for="amount" class="form-label">Amount (Minimum $100):</label>
                                    <input type="number" class="form-control" id="amount" name="amount" step="0.01" min="100" required>
                                </div>
                                <div class="mb-3">
                                    <label for="payment_method" class="form-label">Payment Method:</label>
                                    <select class="form-control" id="payment_method" name="payment_method" required>
                                        <option value="mpesa">M-Pesa</option>
                                        <!-- Add other payment methods if needed -->
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary">Withdraw</button>
                            </form>
                        </div>
                    </div>

                    <!-- Display All Withdrawals -->
                    <div class="card mt-4">
                        <div class="card-header">
                            <h5 class="card-title mb-0">All Withdrawals</h5>
                        </div>
                        <div class="card-body">
                            <?php if (count($withdrawals) > 0): ?>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Amount</th>
                                            <th>Payment Method</th>
                                            <th>Status</th>
                                            <th>Request Date (EAT)</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($withdrawals as $withdrawal): ?>
                                            <tr>
                                                <td>$<?php echo number_format($withdrawal['amount'], 2); ?></td>
                                                <td><?php echo htmlspecialchars($withdrawal['payment_method']); ?></td>
                                                <td>
                                                    <?php if ($withdrawal['status'] === 'pending'): ?>
                                                        <span class="status-pending">Pending</span>
                                                    <?php elseif ($withdrawal['status'] === 'approved'): ?>
                                                        <span class="status-approved">Approved</span>
                                                    <?php elseif ($withdrawal['status'] === 'rejected'): ?>
                                                        <span class="status-rejected">Rejected</span>
                                                    <?php else: ?>
                                                        <?php echo htmlspecialchars($withdrawal['status']); ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo htmlspecialchars($withdrawal['created_at']); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            <?php else: ?>
                                <p>No withdrawals found.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </main>

            <!-- Footer -->
            <footer class="footer">
                <div class="container-fluid">
                    <div class="row text-muted">
                        <div class="col-6 text-start">
                            <p class="mb-0">
                                <a class="text-muted" href="https://tecchhubke.site" target="_blank"><strong>Tecchhubke Softwares</strong></a> - <a class="text-muted" href="https://techhubke.site" target="_blank"><strong>KE</strong></a> &copy;
                            </p>
                        </div>
                        <div class="col-6 text-end">
                            <ul class="list-inline">
                                <li class="list-inline-item">
                                    <a class="text-muted" href="#" target="_blank">Support</a>
                                </li>
                                <li class="list-inline-item">
                                    <a class="text-muted" href="#" target="_blank">Help Center</a>
                                </li>
                                <li class="list-inline-item">
                                    <a class="text-muted" href="#" target="_blank">Privacy</a>
                                </li>
                                <li class="list-inline-item">
                                    <a class="text-muted" href="#" target="_blank">Terms</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <script src="js/app.js"></script>
</body>
</html>