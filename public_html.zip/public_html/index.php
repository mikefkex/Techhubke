<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Primary Meta Tags -->
<meta name="description" content="TechHubKE - Leading technology solutions provider in Kenya offering web development, mobile apps, and digital transformation services.">
<meta name="author" content="TechHubKE">
<meta name="keywords" content="TechHubKE, tech Kenya, web development Nairobi, mobile apps Kenya, digital solutions, software development, tech news Africa">
<meta name="robots" content="index, follow">
<meta name="google-adsense-account" content="ca-pub-5971275921484393">
<title>TechHubKE | Web & Mobile Technology Solutions</title>

<!-- Google Adsense -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-5971275921484393" crossorigin="anonymous"></script>

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="https://techhubke.site/">
<meta property="og:title" content="TechHubKE | You IT solution Partner">
<meta property="og:description" content="Professional web development, mobile applications, and digital solutions for Kenyan businesses.">
<meta property="og:image" content="https://techhubke.site/images/social-preview.jpg">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="https://techhubke.site/">
<meta property="twitter:title" content="TechHubKE | Kenya's Technology Partner">
<meta property="twitter:description" content="Professional web development, mobile applications, and digital solutions for Kenyan businesses.">
<meta property="twitter:image" content="https://techhubke.site/images/social-preview.jpg">

<!-- Brand Consistency -->
<meta name="application-name" content="TechHubKE">
<meta name="apple-mobile-web-app-title" content="TechHubKE">
<meta name="theme-color" content="#E91E63">

<!-- Canonical URL -->
<link rel="canonical" href="https://techhubke.site/">
    <link rel="icon" href="images/favicon.jpg" >
    <link rel="stylesheet" href="css/boxicons.min.css">
    <link rel="stylesheet" href="css/app.css">
    <style>

    </style>
</head>
<body>
    <header>
        <nav>
            <div class="logo">
                <img src="images/logo.png" alt="Webmasters Kenya Logo" class="logo-img">
            </div>
            <i class="bx bx-menu" id="menuIcon"></i>
            <div class="nav-links">
                <a href="#home">Home</a>
                <a href="#services">Services</a>
                <a href="#solutions">Solutions</a>
                <a href="#about">About</a>
                <a href="#contact">Contact</a>
                <div class="search-container">
                    <i class='bx bx-search' id="searchIcon"></i>
                    <div class="search-box" id="searchBox">
                        <input type="text" placeholder="Search..." id="searchInput" aria-label="Search website">
                        <button class="search-btn" aria-label="Submit search">
                            <i class='bx bx-search'></i> Search
                        </button>
                        <div class="search-results" id="searchResults"></div>
                    </div>
                </div>
                <i class='bx bx-moon' id="themeToggle"></i>
            </div>
        </nav>
    </header>

    <main class="main-content">
        <!-- Main Slideshow Section -->
        <section class="main-slideshow">
            <div class="slideshow-container">
                <!-- Slide 1 - Web Development -->
                <div class="slide fade">
                    <img src="images/web-development.jpg" 
                         alt="Web development illustration"
                         loading="lazy">
                    <div class="slide-content">
                        <h2>Web Development</h2>
                        <p>Custom websites and web applications built with modern technologies</p>
                        <a href="#contact" class="btn">Learn More</a>
                    </div>
                </div>
                
                <!-- Slide 2 - SEO -->
                <div class="slide fade">
                    <img src="images/seo.jpg" 
                         alt="SEO illustration"
                         loading="lazy">
                    <div class="slide-content">
                        <h2>Search Engine Optimization</h2>
                        <p>Improve your search rankings and online visibility</p>
                        <a href="#contact" class="btn">Get Started</a>
                    </div>
                </div>
                
                <!-- Slide 3 - Graphic Design -->
                <div class="slide fade">
                    <img src="images/graphic-design.jpeg" 
                         alt="Graphic design illustration"
                         loading="lazy">
                    <div class="slide-content">
                        <h2>Graphic Design</h2>
                        <p>Professional branding and visual assets for your business</p>
                        <a href="#contact" class="btn">View Portfolio</a>
                    </div>
                </div>
                
                <!-- Navigation arrows -->
                <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
                <a class="next" onclick="plusSlides(1)">&#10095;</a>
            </div>
            
            <!-- Navigation dots -->
            <div class="dots-container">
                <span class="dot" onclick="currentSlide(1)"></span>
                <span class="dot" onclick="currentSlide(2)"></span>
                <span class="dot" onclick="currentSlide(3)"></span>
            </div>
        </section>

        <!-- Hero Section -->
        <section class="hero" id="home">
            <div class="hero-content">
                <h1>TechHub Solutions</h1>
                <div class="divider"></div>
                <p class="hero-description">
                    <span class="drop-cap">A</span>t Techhubke Kenya , we provide innovative, cutting-edge technology solutions tailored to meet the unique needs of businesses in Kenya and beyond. With over two decades of experience in the software development industry, we have built a reputation as a trusted partner for organizations looking to streamline their operations, enhance their digital presence, and adopt modern technologies.
                </p>
            </div>
        </section>

        <!-- Services Section -->
        <section class="services" id="services">
            <h2 class="section-title">Our Services</h2>
            <div class="divider"></div>
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-header">
                        <i class='bx bx-code-alt'></i>
                        <h3>Web Development</h3>
                    </div>
                    <p>Custom websites and web applications built with modern technologies.</p>
                </div>
                <div class="service-card">
                    <div class="service-header">
                        <i class='bx bx-palette'></i>
                        <h3>Web Design</h3>
                    </div>
                    <p>Beautiful, user-friendly designs that convert visitors to customers.</p>
                </div>
                <div class="service-card">
                    <div class="service-header">
                        <i class='bx bx-cog'></i>
                        <h3>Web Maintenance</h3>
                    </div>
                    <p>Ongoing support and updates to keep your site running smoothly.</p>
                </div>
                <div class="service-card">
                    <div class="service-header">
                        <i class='bx bx-brush'></i>
                        <h3>Graphic Design</h3>
                    </div>
                    <p>Professional branding and visual assets for your business.</p>
                </div>
                <div class="service-card">
                    <div class="service-header">
                        <i class='bx bx-search-alt'></i>
                        <h3>SEO Services</h3>
                    </div>
                    <p>Improve your search rankings and online visibility.</p>
                </div>
                <div class="service-card">
                    <div class="service-header">
                        <i class='bx bx-mobile-alt'></i>
                        <h3>Mobile App Development</h3>
                    </div>
                    <p>Cross-platform mobile applications for iOS and Android.</p>
                </div>
            </div>
        </section>

<!-- Clients/Partners Section -->
<section class="clients">
    <h2 class="section-title">Trusted by over 20 companies & small businesses</h2>
    <div class="divider"></div>
    <div class="clients-grid">
        <div class="client-logo">
            <img src="images/glovo.png" alt="Glovo" loading="lazy">
        </div>
        <div class="client-logo">
            <img src="images/tata.png" alt="TATA" loading="lazy">
        </div>
        <div class="client-logo">
            <img src="images/logo-wide.png" alt="Kiambu National Polytechnic" loading="lazy">
        </div>
        <div class="client-logo">
            <img src="images/custom-white-bg.png" alt="Peak" loading="lazy">
        </div>
        <div class="client-logo">
            <img src="images/peak.png" alt="AFRICA" loading="lazy">
        </div>
                <div class="client-logo">
            <img src="images/naivas.png" alt="naivas" loading="lazy">
        </div>
    </div>
</section>

        <!-- Contact Section -->
        <section class="contact" id="contact">
            <h2 class="section-title">Contact Us</h2>
            <div class="divider"></div>
            <form class="contact-form">
                <div class="form-group">
                    <input type="text" placeholder="Your Name" required>
                </div>
                <div class="form-group">
                    <input type="email" placeholder="Your Email" required>
                </div>
                <div class="form-group">
                    <textarea placeholder="Your Message" required></textarea>
                </div>
                <button type="submit" class="btn">Send Message</button>
            </form>
        </section>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-content">
            <div class="footer-section">
                <h3>Techhubke</h3>
                <p>Your IT solutions partner.</p>
            </div>
            <div class="footer-section">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="#home">Home</a></li>
                    <li><a href="#services">Services</a></li>
                    <li><a href="#solutions">Solutions</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
            </div>
            <div class="footer-section">
                <h3>Contact Info</h3>
                <p><i class='bx bx-map'></i> Nairobi, Kenya</p>
                <p><i class='bx bx-phone'></i> +254 112 876452</p>
                <p><i class='bx bx-envelope'></i> info@techhubke.site</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; 2023 Techhubke. All rights reserved.</p>
        </div>
    </footer>

    <script>
        // Mobile menu toggle
        document.addEventListener('DOMContentLoaded', function() {
            const menuIcon = document.getElementById('menuIcon');
            const navLinks = document.querySelector('.nav-links');
            
            // Calculate nav links height for mobile search positioning
            const navLinksHeight = navLinks.offsetHeight;
            document.documentElement.style.setProperty('--nav-links-height', `${navLinksHeight}px`);
            
            menuIcon.addEventListener('click', function() {
                navLinks.classList.toggle('active');
            });
            
            // Close menu when clicking on a link
            document.querySelectorAll('.nav-links a').forEach(link => {
                link.addEventListener('click', function() {
                    if (window.innerWidth <= 768) {
                        navLinks.classList.remove('active');
                    }
                });
            });

            // Search functionality
            const searchIcon = document.getElementById('searchIcon');
            const searchBox = document.getElementById('searchBox');
            const searchInput = document.getElementById('searchInput');
            const searchResults = document.getElementById('searchResults');
            
            // Toggle search box
            searchIcon.addEventListener('click', function(e) {
                e.stopPropagation();
                searchBox.classList.toggle('active');
                if (searchBox.classList.contains('active')) {
                    searchInput.focus();
                } else {
                    clearSearch();
                }
            });
            
            // Close search when clicking outside
            document.addEventListener('click', function(e) {
                if (!searchBox.contains(e.target) && e.target !== searchIcon && e.target !== menuIcon) {
                    searchBox.classList.remove('active');
                    clearSearch();
                }
            });
            
            // Search as you type
            searchInput.addEventListener('input', function() {
                performSearch(this.value);
            });
            
            // Search on button click
            document.querySelector('.search-btn').addEventListener('click', function() {
                performSearch(searchInput.value);
            });
            
            // Search on Enter key
            searchInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    performSearch(this.value);
                }
            });
            
            function performSearch(query) {
                if (query.trim() === '') {
                    clearSearch();
                    return;
                }
                
                const searchTerm = query.toLowerCase();
                const elements = document.querySelectorAll('h1, h2, h3, h4, h5, h6, p, li');
                let results = [];
                
                elements.forEach(el => {
                    if (el.offsetParent !== null) { // Only visible elements
                        const text = el.textContent.toLowerCase();
                        if (text.includes(searchTerm)) {
                            results.push({
                                element: el,
                                text: el.textContent
                            });
                        }
                    }
                });
                
                displayResults(results, searchTerm);
            }
            
            function displayResults(results, term) {
                searchResults.innerHTML = '';
                
                if (results.length === 0) {
                    searchResults.style.display = 'block';
                    searchResults.innerHTML = '<div class="search-result-item">No results found</div>';
                    return;
                }
                
                searchResults.style.display = 'block';
                results.slice(0, 5).forEach(result => {
                    const resultItem = document.createElement('div');
                    resultItem.className = 'search-result-item';
                    
                    // Highlight matching text in result preview
                    const preview = result.text.replace(
                        new RegExp(term, 'gi'), 
                        match => `<mark>${match}</mark>`
                    );
                    
                    resultItem.innerHTML = preview.length > 100 
                        ? preview.substring(0, 100) + '...' 
                        : preview;
                    
                    resultItem.addEventListener('click', function() {
                        result.element.scrollIntoView({
                            behavior: 'smooth',
                            block: 'center'
                        });
                        highlightElement(result.element, term);
                        searchBox.classList.remove('active');
                    });
                    
                    searchResults.appendChild(resultItem);
                });
                
                if (results.length > 5) {
                    const moreItem = document.createElement('div');
                    moreItem.className = 'search-result-item';
                    moreItem.textContent = `+ ${results.length - 5} more results`;
                    moreItem.style.fontStyle = 'italic';
                    searchResults.appendChild(moreItem);
                }
            }
            
            function highlightElement(element, term) {
                // Remove previous highlights
                document.querySelectorAll('mark.search-highlight').forEach(mark => {
                    mark.outerHTML = mark.innerHTML;
                });
                
                if (element.textContent.toLowerCase().includes(term)) {
                    const regex = new RegExp(term, 'gi');
                    element.innerHTML = element.innerHTML.replace(
                        regex, 
                        match => `<mark class="search-highlight">${match}</mark>`
                    );
                }
            }
            
            function clearSearch() {
                searchInput.value = '';
                searchResults.innerHTML = '';
                searchResults.style.display = 'none';
                document.querySelectorAll('mark.search-highlight').forEach(mark => {
                    mark.outerHTML = mark.innerHTML;
                });
            }

            // Dark mode toggle
            const themeToggle = document.getElementById('themeToggle');
            themeToggle.addEventListener('click', function() {
                document.body.classList.toggle('dark-mode');
                
                if (document.body.classList.contains('dark-mode')) {
                    themeToggle.classList.remove('bx-moon');
                    themeToggle.classList.add('bx-sun');
                } else {
                    themeToggle.classList.remove('bx-sun');
                    themeToggle.classList.add('bx-moon');
                }
            });

            // Slideshow functionality
            let slideIndex = 1;
            showSlides(slideIndex);

            function plusSlides(n) {
                showSlides(slideIndex += n);
            }

            function currentSlide(n) {
                showSlides(slideIndex = n);
            }

            function showSlides(n) {
                let i;
                let slides = document.getElementsByClassName("slide");
                let dots = document.getElementsByClassName("dot");
                
                if (n > slides.length) {slideIndex = 1}    
                if (n < 1) {slideIndex = slides.length}
                
                for (i = 0; i < slides.length; i++) {
                    slides[i].style.display = "none";  
                }
                
                for (i = 0; i < dots.length; i++) {
                    dots[i].className = dots[i].className.replace(" active", "");
                }
                
                slides[slideIndex-1].style.display = "block";  
                dots[slideIndex-1].className += " active";
                
                // Auto-advance slides every 5 seconds
                setTimeout(() => {
                    plusSlides(1);
                }, 5000);
            }



            // Smooth scrolling for anchor links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function(e) {
                    e.preventDefault();
                    
                    const targetId = this.getAttribute('href');
                    const targetElement = document.querySelector(targetId);
                    
                    if (targetElement) {
                        window.scrollTo({
                            top: targetElement.offsetTop - 70,
                            behavior: 'smooth'
                        });
                    }
                });
            });

            // Image loading enhancement
            const images = document.querySelectorAll('img[loading="lazy"]');
            
            images.forEach(img => {
                if (img.complete) {
                    img.classList.add('loaded');
                } else {
                    img.addEventListener('load', function() {
                        this.classList.add('loaded');
                    });
                    
                    // Fallback if load event doesn't fire
                    setTimeout(() => {
                        img.classList.add('loaded');
                    }, 1000);
                }
            });
        });
    </script>
</body>
</html>