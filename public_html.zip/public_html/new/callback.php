<?php
// Database configuration
$dbHost = 'sql111.infinityfree.com';      // Database host
$dbUser = 'if0_36840178';           // Database username
$dbPass = '7fgITKaozohjp';               // Database password
$dbName = 'if0_36840178_payments';     // Database name

// Create a database connection
$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the raw POST data
$rawData = file_get_contents("php://input");

// Decode the JSON data
$data = json_decode($rawData, true);

// Check if the data is valid
if (json_last_error() === JSON_ERROR_NONE && isset($data['transaction'])) {
    $transaction = $data['transaction'];

    // Extract transaction details
    $transactionId = $transaction['id'];
    $amount = $transaction['amount'];
    $phoneNumber = $transaction['phoneNumber'];
    $status = $transaction['status'];
    $reference = $transaction['reference'];
    $customerName = $transaction['customerName'];
    $timestamp = date('Y-m-d H:i:s');

    // Prepare the SQL statement
    $stmt = $conn->prepare("INSERT INTO transactions (transaction_id, amount, phone_number, status, reference, customer_name, timestamp) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sdsssss", $transactionId, $amount, $phoneNumber, $status, $reference, $customerName, $timestamp);

    // Execute the statement
    if ($stmt->execute()) {
        http_response_code(200);
        echo json_encode(['status' => 'success', 'message' => 'Transaction saved successfully']);
    } else {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Failed to save transaction']);
    }

    // Close the statement
    $stmt->close();
} else {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid data received']);
}

// Close the database connection
$conn->close();
?>