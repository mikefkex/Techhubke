<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__.'/status_errors.log');

include 'config.php';
include 'db_connection.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$reference = $_GET['reference'] ?? '';

if (empty($reference)) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Missing reference parameter"
    ]);
    exit;
}

try {
    // 1. Check database first
    $stmt = $pdo->prepare("SELECT status, provider_reference FROM transactions WHERE api_reference = ?");
    $stmt->execute([$reference]);
    $tx = $stmt->fetch();
    
    if ($tx) {
        // Normalize status (fix QUALID, COMPLETED, etc.)
        $status = strtoupper($tx['status']);
        if ($status === 'QUALID' || $status === 'COMPLETED') {
            $status = 'SUCCESS';
        }
        
        // If we have a final status with reference, return it
        if (in_array($status, ['SUCCESS','FAILED']) && !empty($tx['provider_reference'])) {
            echo json_encode([
                "status" => $status,
                "provider_reference" => $tx['provider_reference'],
                "source" => "database"
            ]);
            exit;
        }
    }
    
    // 2. Verify with PayHero API
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => 'https://backend.payhero.co.ke/api/v2/transaction-status?reference='.urlencode($reference),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: '.$paymentConfig['basicAuthToken'],
            'Content-Type: application/json'
        ],
        CURLOPT_TIMEOUT => 15
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    // Log the verification attempt
    file_put_contents(__DIR__.'/status_checks.log', 
        date('Y-m-d H:i:s')." | ".$reference." | HTTP ".$httpCode."\n".
        "Response: ".$response."\n\n",
        FILE_APPEND
    );
    
    $responseData = json_decode($response, true) ?: [];
    
    // Determine actual status
    $verifiedStatus = 'PENDING';
    $providerRef = null;
    
    if ($httpCode === 200) {
        $status = strtoupper($responseData['status'] ?? '');
        if ($status === 'SUCCESS' || $status === 'COMPLETED') {
            $verifiedStatus = 'SUCCESS';
        } elseif (stripos($response, 'success') !== false || 
                 stripos($response, 'completed') !== false) {
            $verifiedStatus = 'SUCCESS';
        }
        
        $providerRef = extractMpesaReference($responseData);
    }
    
    // Update database if we got a definitive status
    if (in_array($verifiedStatus, ['SUCCESS','FAILED'])) {
        $updateStmt = $pdo->prepare("UPDATE transactions SET 
            status = :status,
            provider_reference = COALESCE(:provider_ref, provider_reference),
            updated_at = NOW()
            WHERE api_reference = :api_ref");
        
        $updateStmt->execute([
            ':status' => $verifiedStatus,
            ':provider_ref' => $providerRef,
            ':api_ref' => $reference
        ]);
    }
    
    // Return the verified status
    echo json_encode([
        "status" => $verifiedStatus,
        "provider_reference" => $providerRef,
        "source" => "api_verified"
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Status check failed",
        "error" => $e->getMessage()
    ]);
}

/**
 * Consistent M-Pesa reference extraction
 */
function extractMpesaReference($responseData) {
    $paths = [
        ['provider_reference'],
        ['data', 'provider_reference'],
        ['transaction', 'reference'],
        ['reference'],
        ['requestId'],
        ['MerchantRequestID']
    ];
    
    foreach ($paths as $path) {
        $value = $responseData;
        foreach ($path as $key) {
            if (!isset($value[$key])) continue 2;
            $value = $value[$key];
        }
        
        if ($value && is_string($value)) {
            $value = trim($value);
            // Match standard M-Pesa reference format
            if (preg_match('/^[A-Z0-9]{8,12}$/', $value)) {
                return $value;
            }
            // Extract from longer references
            if (preg_match('/^([A-Z0-9]{8,12})[-_]/', $value, $matches)) {
                return $matches[1];
            }
        }
    }
    return null;
}