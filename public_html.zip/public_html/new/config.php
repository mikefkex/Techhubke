<?php
$paymentConfig=[
    "channelId"=> 965,//Your payment or wallet channel ID
    "provider"=> "m-pesa",//Value can be m-pesa or sasapay
    "networkCode"=> "63902",// Network code for Safaricom
    "callbackUrl"=> "https://outlier.is-great.org/pay/callback.php",//OPTIONAL: Callback URL to receive payment json payload on success
    "credentialId"=> null,//OPTIONAL: Your custom credential_id
    "basicAuthToken"=>"Basic NWdpS0dKemJtcVplWFFWMlVDcTQ6U3lLT0lmcTNjQ0hvQ2RicTZTbDhHV21yTTVoOGxNYmRjN0VUeHI4ZA==",//Your basic auth token
    "successURL"=>null,//OPTIONAL: URl to redirect user to if payment is success
    "failedURL"=>null//OPTIONAL: URl to redirect user to if payment fails
];