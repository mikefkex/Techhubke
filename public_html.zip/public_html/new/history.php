<?php
include 'db_connection.php';
include 'config.php';

$stmt = $pdo->query("SELECT * FROM transactions ORDER BY created_at DESC");
$transactions = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Transaction History</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Transaction History</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Customer</th>
                    <th>Phone</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>M-Pesa Ref</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($transactions as $tx): ?>
                <tr>
                    <td><?= htmlspecialchars($tx['id']) ?></td>
                    <td><?= htmlspecialchars($tx['customer_name']) ?></td>
                    <td><?= htmlspecialchars($tx['phone_number']) ?></td>
                    <td>KES <?= number_format($tx['amount'], 2) ?></td>
                    <td>
                        <span class="badge bg-<?= $tx['status'] === 'SUCCESS' ? 'success' : ($tx['status'] === 'FAILED' ? 'danger' : 'warning') ?>">
                            <?= htmlspecialchars($tx['status']) ?>
                        </span>
                    </td>
                    <td><?= htmlspecialchars($tx['provider_reference'] ?? 'N/A') ?></td>
                    <td><?= htmlspecialchars($tx['created_at']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>