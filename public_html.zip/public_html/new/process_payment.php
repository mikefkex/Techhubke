<?php
// Enable maximum error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__.'/payment_errors.log');

include 'config.php';
include 'db_connection.php';

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// Get the posted data
$postData = file_get_contents("php://input");
$requestData = json_decode($postData, true);

// Validate required fields
$requiredFields = ['customer_name', 'phone_number', 'amount', 'external_reference'];
foreach ($requiredFields as $field) {
    if (empty($requestData[$field])) {
        http_response_code(400);
        echo json_encode([
            "status" => "error",
            "message" => "Missing required field: $field",
            "code" => "MISSING_FIELD"
        ]);
        exit;
    }
}

// Validate phone number
if (!preg_match('/^0[0-9]{9}$/', $requestData['phone_number'])) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Invalid phone number format",
        "code" => "INVALID_PHONE"
    ]);
    exit;
}

// Generate unique reference
$api_reference = 'TX'.time().rand(100,999);

try {
    // Begin database transaction
    $pdo->beginTransaction();
    
    // Save initial transaction record
    $stmt = $pdo->prepare("INSERT INTO transactions (
        customer_name, phone_number, amount, external_reference,
        api_reference, status, channel_id, provider, network_code,
        created_at, updated_at
    ) VALUES (
        :customer_name, :phone_number, :amount, :external_reference,
        :api_reference, 'PENDING', :channel_id, :provider, :network_code,
        NOW(), NOW()
    )");
    
    $stmt->execute([
        ':customer_name' => $requestData['customer_name'],
        ':phone_number' => $requestData['phone_number'],
        ':amount' => $requestData['amount'],
        ':external_reference' => $requestData['external_reference'],
        ':api_reference' => $api_reference,
        ':channel_id' => $requestData['channel_id'],
        ':provider' => $requestData['provider'],
        ':network_code' => $requestData['network_code']
    ]);
    
    // Add reference to API request
    $requestData['reference'] = $api_reference;
    
    // Process payment with PayHero API
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => 'https://backend.payhero.co.ke/api/v2/payments',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($requestData),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: '.$paymentConfig['basicAuthToken']
        ],
        CURLOPT_TIMEOUT => 30
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    // Log the raw response
    file_put_contents(__DIR__.'/payment_responses.log', 
        date('Y-m-d H:i:s')." | ".$api_reference." | HTTP ".$httpCode."\n".
        "Request: ".json_encode($requestData)."\n".
        "Response: ".$response."\n\n",
        FILE_APPEND
    );
    
    if ($error) {
        throw new Exception("cURL Error: ".$error);
    }
    
    $responseData = json_decode($response, true);
    
    // Determine if payment was successful
    $isSuccess = false;
    $providerRef = null;
    
    if ($httpCode >= 200 && $httpCode < 300) {
        // Check multiple success indicators
        $status = strtoupper($responseData['status'] ?? '');
        if ($status === 'SUCCESS' || $status === 'COMPLETED') {
            $isSuccess = true;
        } elseif (stripos($response, 'success') !== false || 
                 stripos($response, 'completed') !== false) {
            $isSuccess = true;
        }
        
        // Extract provider reference
        $providerRef = extractMpesaReference($responseData);
    }
    
    // Update transaction status
    $updateStatus = $isSuccess ? 'SUCCESS' : 'FAILED';
    $updateStmt = $pdo->prepare("UPDATE transactions SET 
        status = :status,
        provider_reference = :provider_ref,
        updated_at = NOW()
        WHERE api_reference = :api_ref");
    
    $updateStmt->execute([
        ':status' => $updateStatus,
        ':provider_ref' => $providerRef,
        ':api_ref' => $api_reference
    ]);
    
    // Commit transaction
    $pdo->commit();
    
    // Return response
    if ($isSuccess) {
        echo json_encode([
            "status" => "SUCCESS",
            "message" => "Payment processed successfully",
            "reference" => $api_reference,
            "mpesa_reference" => $providerRef,
            "timestamp" => date('Y-m-d H:i:s')
        ]);
    } else {
        http_response_code(400);
        echo json_encode([
            "status" => "FAILED",
            "message" => $responseData['message'] ?? 'Payment processing failed',
            "reference" => $api_reference
        ]);
    }
    
} catch (Exception $e) {
    // Roll back transaction on error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    http_response_code(500);
    echo json_encode([
        "status" => "ERROR",
        "message" => "Payment processing error",
        "error" => $e->getMessage(),
        "reference" => $api_reference ?? null
    ]);
    
    error_log("Payment Error: ".$e->getMessage());
}

/**
 * Extracts M-Pesa reference from API response
 */
function extractMpesaReference($responseData) {
    $paths = [
        ['provider_reference'],
        ['data', 'provider_reference'],
        ['transaction', 'reference'],
        ['reference'],
        ['requestId'],
        ['MerchantRequestID']
    ];
    
    foreach ($paths as $path) {
        $value = $responseData;
        foreach ($path as $key) {
            if (!isset($value[$key])) continue 2;
            $value = $value[$key];
        }
        
        if ($value && is_string($value)) {
            $value = trim($value);
            // Match formats like TCQ753SPIN or LGR019G3X2
            if (preg_match('/^[A-Z0-9]{8,12}$/', $value)) {
                return $value;
            }
            // Handle longer references (TCQ54PFJ4X-a08-4dd1...)
            if (preg_match('/^([A-Z0-9]{8,12})[-_]/', $value, $matches)) {
                return $matches[1];
            }
        }
    }
    return null;
}