<?php
include 'config.php';
include 'db_connection.php';

header("Content-Type: application/json");

$reference = $_GET['reference'] ?? '';

try {
    $stmt = $pdo->prepare("SELECT 
        status, 
        provider_reference,
        customer_name,
        amount,
        created_at
        FROM transactions 
        WHERE api_reference = ?");
    $stmt->execute([$reference]);
    $tx = $stmt->fetch();
    
    if ($tx) {
        // Normalize status
        $status = strtoupper($tx['status']);
        if ($status === 'QUALID') $status = 'SUCCESS';
        
        echo json_encode([
            'status' => $status,
            'provider_reference' => $tx['provider_reference'],
            'customer_name' => $tx['customer_name'],
            'amount' => $tx['amount'],
            'timestamp' => $tx['created_at'],
            'verified' => true
        ]);
    } else {
        echo json_encode([
            'error' => 'Transaction not found',
            'reference' => $reference,
            'verified' => false
        ]);
    }
} catch (PDOException $e) {
    echo json_encode([
        'error' => $e->getMessage(),
        'verified' => false
    ]);
}