<?php
require_once 'config.php';
require_once 'database.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set JSON header
header('Content-Type: application/json');

try {
    // Log raw callback data for debugging
    $rawData = file_get_contents('php://input');
    error_log("Raw Callback Data: " . $rawData);

    $callbackData = json_decode($rawData, true);

    if (!$callbackData || !isset($callbackData['response'])) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Invalid callback data']);
        exit;
    }

    $response = $callbackData['response'];
    
    // Validate required fields
    $requiredFields = ['Status', 'MpesaReceiptNumber', 'ResultCode', 'ResultDesc', 'CheckoutRequestID'];
    foreach ($requiredFields as $field) {
        if (!isset($response[$field])) {
            error_log("Missing required field: $field");
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => "Missing $field"]);
            exit;
        }
    }

    $db = new Database();
    $sql = "UPDATE payments SET 
            status = '" . $db->escapeString($response['Status']) . "',
            mpesa_receipt_number = '" . $db->escapeString($response['MpesaReceiptNumber']) . "',
            result_code = '" . $db->escapeString($response['ResultCode']) . "',
            result_desc = '" . $db->escapeString($response['ResultDesc']) . "'
            WHERE checkout_request_id = '" . $db->escapeString($response['CheckoutRequestID']) . "'";
    
    if ($db->query($sql)) {
        http_response_code(200);
        echo json_encode(['status' => 'success', 'message' => 'Payment updated successfully']);
    } else {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Failed to update payment']);
    }
} catch (Exception $e) {
    error_log("Callback Processing Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Internal Server Error: ' . $e->getMessage()]);
}
?>