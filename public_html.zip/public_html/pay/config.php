<?php
// config.php
define('DB_HOST', 'localhost');
define('DB_USER', 'techhubk_payments');
define('DB_PASS', 'avTD4bThv7QVskYwTqXA');
define('DB_NAME', 'techhubk_payments');

define('API_USERNAME', '5giKGJzbmqZeXQV2UCq4');
define('API_PASSWORD', 'SyKOIfq3cCHoCdbq6Sl8GWmrM5h8lMbdc7ETxr8d');