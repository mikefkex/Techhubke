<?php
// database.php
class Database {
    private $conn;

    public function __construct() {
        $this->conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    // Updated to support both regular and prepared queries
    public function query($sql, $params = []) {
        // Prepare the statement
        $stmt = $this->conn->prepare($sql);
        if (!$stmt) {
            error_log("SQL Prepare Error: " . $this->conn->error);
            return false;
        }

        // Bind parameters if provided
        if (!empty($params)) {
            $types = '';
            foreach ($params as $param) {
                if (is_int($param)) {
                    $types .= 'i';  // integer
                } elseif (is_float($param)) {
                    $types .= 'd';  // double
                } else {
                    $types .= 's';  // string
                }
            }
            $stmt->bind_param($types, ...$params);
        }

        // Execute the query
        $success = $stmt->execute();
        
        if (!$success) {
            error_log("SQL Execute Error: " . $stmt->error);
            return false;
        }

        return $stmt;
    }

    public function escapeString($str) {
        return $this->conn->real_escape_string($str);
    }

    // Add this method to get the last error
    public function getLastError() {
        return $this->conn->error;
    }

    public function __destruct() {
        $this->conn->close();
    }
}