<?php
require_once 'config.php';
require_once 'database.php';

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set JSON header
header('Content-Type: application/json');

try {
    // Validate external reference
    if (!isset($_GET['external_reference']) || empty($_GET['external_reference'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid or missing external reference']);
        exit;
    }

    $external_reference = $_GET['external_reference'];

    $db = new Database();
    $sql = "SELECT * FROM payments WHERE external_reference = '" . $db->escapeString($external_reference) . "'";
    
    $result = $db->query($sql);

    if ($result && $result->num_rows > 0) {
        $payment = $result->fetch_assoc();
        echo json_encode(['success' => true, 'payment' => $payment]);
    } else {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Payment not found']);
    }
} catch (Exception $e) {
    error_log("Payment Status Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Internal Server Error: ' . $e->getMessage()]);
}
?>