<!DOCTYPE html>
<html lang="en" data-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>STK Push Payment Form</title>
    <link href="https://cdn.jsdelivr.net/npm/daisyui@3.5.0/dist/full.css" rel="stylesheet" type="text/css" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.9.3/dist/confetti.browser.min.js"></script>
    <style>
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes fadeOut {
            from { opacity: 1; }
            to { opacity: 0; }
        }
        .fade-in {
            animation: fadeIn 0.5s ease-in;
        }
        .fade-out {
            animation: fadeOut 0.5s ease-out;
        }
        .spinner {
            border: 4px solid rgba(0, 0, 0, 0.1);
            border-left-color: #22c55e;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body class="bg-gray-100 flex justify-center items-center min-h-screen">
    <div class="w-full max-w-md p-8 bg-white rounded-lg shadow-lg">
        <h2 class="text-2xl font-bold mb-6 text-center">STK Push Payment</h2>
        
        <form id="stkPushForm" class="space-y-4">
            <div class="form-control">
                <label class="label" for="amount">
                    <span class="label-text">Amount</span>
                </label>
                <input type="number" id="amount" name="amount" 
                       placeholder="Enter amount" 
                       min="1" 
                       class="input input-bordered" 
                       required>
            </div>
            
            <div class="form-control">
                <label class="label" for="phone">
                    <span class="label-text">Phone Number</span>
                </label>
                <input type="tel" id="phone" name="phone" 
                       placeholder="Enter phone number (e.g. 254712345678)" 
                       pattern="254[0-9]{9}"
                       class="input input-bordered" 
                       required>
                <small class="text-gray-500 mt-1">Format: 254712345678</small>
            </div>
            
            <button type="submit" id="submitBtn" class="btn btn-primary w-full">
                Initiate Payment
            </button>
        </form>

        <div id="notification" class="mt-4 p-4 rounded-lg hidden"></div>
        <div id="paymentStatus" class="mt-4 p-4 rounded-lg hidden"></div>
    </div>

    <script>
        const form = document.getElementById('stkPushForm');
        const notification = document.getElementById('notification');
        const paymentStatus = document.getElementById('paymentStatus');
        const submitBtn = document.getElementById('submitBtn');

        // Enhanced notification function
        function showNotification(message, type = 'info') {
            // Reset previous state
            notification.classList.remove('bg-red-100', 'bg-green-100', 'bg-blue-100', 'text-red-700', 'text-green-700', 'text-blue-700');
            
            // Set appropriate classes based on type
            const typeClasses = {
                'error': ['bg-red-100', 'text-red-700'],
                'success': ['bg-green-100', 'text-green-700'],
                'info': ['bg-blue-100', 'text-blue-700']
            };

            notification.classList.add(...typeClasses[type]);
            notification.textContent = message;
            notification.classList.remove('hidden');
            notification.classList.add('fade-in');
        }

        // Validate phone number format
        function validatePhoneNumber(phone) {
            const phoneRegex = /^254[0-9]{9}$/;
            return phoneRegex.test(phone);
        }

        // Initiate payment with enhanced error handling
        async function initiatePayment(amount, phone) {
            try {
                submitBtn.disabled = true;
                submitBtn.innerHTML = `
                    <div class="flex items-center justify-center">
                        <div class="spinner mr-2"></div>
                        Processing...
                    </div>
                `;

                const response = await fetch('initiate_payment.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `amount=${encodeURIComponent(amount)}&phone_number=${encodeURIComponent(phone)}`
                });

                // Check if response is OK
                if (!response.ok) {
                    const errorText = await response.text();
                    throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
                }

                const data = await response.json();
                
                if (!data.success) {
                    throw new Error(data.message || 'Unknown error occurred');
                }
                
                return data;
            } catch (error) {
                console.error('Payment initiation error:', error);
                showNotification(error.message, 'error');
                throw error;
            } finally {
                submitBtn.disabled = false;
                submitBtn.innerHTML = 'Initiate Payment';
            }
        }

        // Payment status polling with improved error handling
        function pollPaymentStatus(externalReference) {
            let attempts = 0;
            const maxAttempts = 20; // Limit polling attempts
            const pollInterval = 5000; // 5 seconds

            const intervalId = setInterval(async () => {
                attempts++;

                if (attempts > maxAttempts) {
                    clearInterval(intervalId);
                    showNotification('Payment check timed out. Please check manually.', 'error');
                    return;
                }

                try {
                    const response = await fetch(`get_payment_status.php?external_reference=${externalReference}`);
                    
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }

                    const statusResponse = await response.json();

                    if (!statusResponse.success) {
                        // Continue polling if payment not found
                        return;
                    }

                    const payment = statusResponse.payment;

                    if (payment.status !== 'PENDING') {
                        clearInterval(intervalId);
                        updatePaymentStatus(payment);
                    }
                } catch (error) {
                    console.error('Payment status polling error:', error);
                }
            }, pollInterval);
        }

        // Update payment status display
        function updatePaymentStatus(data) {
            const statusHtml = `
                <h3 class="font-bold ${data.status === 'SUCCESS' ? 'text-green-700' : 'text-red-700'}">
                    ${data.status}
                </h3>
                <p>Amount: ${data.amount}</p>
                <p>Receipt Number: ${data.mpesa_receipt_number || 'N/A'}</p>
                <p>Phone: ${data.phone_number}</p>
                <p>Result: ${data.result_desc || 'No description'}</p>
            `;

            paymentStatus.innerHTML = statusHtml;
            paymentStatus.className = `mt-4 p-4 rounded-lg ${data.status === 'SUCCESS' ? 'bg-green-100' : 'bg-red-100'}`;
            paymentStatus.classList.remove('hidden');
            paymentStatus.classList.add('fade-in');

            if (data.status === 'SUCCESS') {
                triggerConfetti();
            }
        }

        // Form submission handler
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const amount = document.getElementById('amount').value;
            const phone = document.getElementById('phone').value;

            // Validate inputs
            if (!amount || amount <= 0) {
                showNotification('Please enter a valid amount', 'error');
                return;
            }

            if (!validatePhoneNumber(phone)) {
                showNotification('Invalid phone number. Use format 254712345678', 'error');
                return;
            }

            try {
                showNotification('Initiating STK push...', 'info');

                const response = await initiatePayment(amount, phone);

                showNotification('STK push initiated successfully!', 'success');
                
                const externalReference = response.data.external_reference || response.data.reference;
                
                if (externalReference) {
                    pollPaymentStatus(externalReference);
                } else {
                    showNotification('Error: External reference not received', 'error');
                }
            } catch (error) {
                // Error is already handled in initiatePayment function
            }
        });

        // Confetti animation (unchanged)
        function triggerConfetti() {
            const count = 200;
            const defaults = { origin: { y: 0.7 } };

            function fire(particleRatio, opts) {
                confetti({
                    ...defaults,
                    ...opts,
                    particleCount: Math.floor(count * particleRatio)
                });
            }

            fire(0.25, { spread: 26, startVelocity: 55 });
            fire(0.2, { spread: 60 });
            fire(0.35, { spread: 100, decay: 0.91, scalar: 0.8 });
            fire(0.1, { spread: 120, startVelocity: 25, decay: 0.92, scalar: 1.2 });
            fire(0.1, { spread: 120, startVelocity: 45 });
        }
    </script>
</body>
</html>