<?php
require_once 'config.php';
require_once 'database.php';
require_once 'token_generator.php';

// Enable detailed error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

function initiatePayment($amount, $phone_number, $channel_id, $external_reference) {
    try {
        $basicAuthToken = generateBasicAuthToken();

        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://backend.payhero.co.ke/api/v2/payments',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode([
                "amount" => floatval($amount),
                "phone_number" => $phone_number,
                "channel_id" => $channel_id,
                "provider" => "m-pesa",
                "external_reference" => $external_reference,
                "callback_url" => "http://techhubke.site/callback.php"
            ]),
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json',
                'Authorization: ' . $basicAuthToken
            ),
            CURLOPT_FAILONERROR => false  // Allow us to handle errors manually
        ));

        $response = curl_exec($curl);
        $httpCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $error = curl_error($curl);
        curl_close($curl);

        // Log detailed error information
        error_log("Payment Initiation Debug:");
        error_log("HTTP Code: $httpCode");
        error_log("API Response: " . $response);
        error_log("cURL Error: " . $error);

        if ($error) {
            return ['success' => false, 'message' => "cURL Error: $error"];
        }

        if ($httpCode != 200 && $httpCode != 201) {
            return ['success' => false, 'message' => "HTTP Error: $httpCode", 'response' => $response];
        }

        $decodedResponse = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            return ['success' => false, 'message' => 'Invalid JSON response', 'response' => $response];
        }

        return ['success' => true, 'data' => $decodedResponse];
    } catch (Exception $e) {
        error_log("Payment Initiation Exception: " . $e->getMessage());
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

// Set headers to ensure JSON response
header('Content-Type: application/json');

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Validate input
        if (!isset($_POST['amount']) || !isset($_POST['phone_number'])) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Missing required parameters']);
            exit;
        }

        $amount = $_POST['amount'];
        $phone_number = $_POST['phone_number'];
        $channel_id = 965;
        $external_reference = 'INV-' . time();

        $response = initiatePayment($amount, $phone_number, $channel_id, $external_reference);

        if ($response['success']) {
            $db = new Database();
            $sql = "INSERT INTO payments (amount, phone_number, external_reference, checkout_request_id, status) 
                    VALUES ('" . $db->escapeString($amount) . "', 
                            '" . $db->escapeString($phone_number) . "', 
                            '" . $db->escapeString($external_reference) . "', 
                            '" . $db->escapeString($response['data']['CheckoutRequestID']) . "', 
                            'PENDING')";
            
            if ($db->query($sql)) {
                echo json_encode([
                    'success' => true, 
                    'message' => 'Payment initiated', 
                    'data' => [
                        'external_reference' => $external_reference,
                        'CheckoutRequestID' => $response['data']['CheckoutRequestID']
                    ]
                ]);
            } else {
                error_log("Database Error: Failed to save payment details");
                http_response_code(500);
                echo json_encode(['success' => false, 'message' => 'Failed to save payment details']);
            }
        } else {
            http_response_code(400);
            echo json_encode($response);
        }
    } else {
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method Not Allowed']);
    }
} catch (Exception $e) {
    error_log("Unexpected Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Internal Server Error: ' . $e->getMessage()]);
}
?>