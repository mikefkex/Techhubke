<?php
// check_callback.php
header('Content-Type: text/plain');

// Test 1: Check if file is accessible
echo "1. Callback endpoint is reachable: ✓\n\n";

// Test 2: Verify POST requests work
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "2. POST requests accepted: ✓\n";
    echo "   Received data:\n";
    print_r(file_get_contents('php://input'));
} else {
    echo "2. POST requests not detected (try accessing this URL with POST)\n";
}

// Test 3: Check database connection
require_once 'config.php';
require_once 'database.php';
try {
    $db = new Database();
    echo "\n3. Database connection successful: ✓\n";
} catch (Exception $e) {
    echo "\n3. Database connection failed: " . $e->getMessage() . "\n";
}

// Test 4: Verify writable logs
$logFile = 'callback_test.log';
file_put_contents($logFile, "Test write at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND);
echo "\n4. Log file writable: " . (file_exists($logFile) ? "✓" : "✗") . "\n";

// Test 5: Full simulation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $testData = [
        'response' => [
            'CheckoutRequestID' => 'ws_CO_TEST_123',
            'ResultCode' => '0',
            'ResultDesc' => 'Test successful',
            'MpesaReceiptNumber' => 'TEST_' . time()
        ]
    ];
    
    $db->query("UPDATE payments SET status='COMPLETED' WHERE checkout_request_id='ws_CO_TEST_123'");
    echo "\n5. Simulated callback processed: ✓\n";
}